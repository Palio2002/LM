/* ============ folha (painel que sobe da base) ============ */
const Folha = {
  aoFechar: null,
  historico: false,
  abrir({ titulo, html, montar, abas, inicial, aoFechar }) {
    $('#folha-t').textContent = titulo;
    if (!this.historico) { try { history.pushState({ folha: 1 }, '', location.href); this.historico = true; } catch (e) { /* ignora */ } }
    this.aoFechar = aoFechar || null;
    const corpo = $('#folha-corpo'); const barra = $('#folha-abas');
    if (abas) {
      barra.hidden = false;
      barra.innerHTML = abas.map(a => `<button role="tab" type="button" data-aba="${a.id}" aria-selected="false">${esc(a.rotulo)}</button>`).join('');
      const ir = id => {
        $$('button', barra).forEach(b => b.setAttribute('aria-selected', String(b.dataset.aba === id)));
        corpo.innerHTML = ''; abas.find(a => a.id === id).montar(corpo);
      };
      barra.onclick = e => { const b = e.target.closest('button'); if (b) ir(b.dataset.aba); };
      ir(inicial || abas[0].id);
    } else {
      barra.hidden = true; barra.onclick = null;
      corpo.innerHTML = html || ''; if (montar) montar(corpo);
    }
    $('#fundo-folha').hidden = false; $('#folha').hidden = false;
    const f = $('#folha-x'); if (f) f.focus({ preventScroll: true });
  },
  fechar(semHistorico) {
    if ($('#folha').hidden) return;
    $('#folha').hidden = true; $('#fundo-folha').hidden = true;
    if (this.historico) { this.historico = false; if (!semHistorico && history.state && history.state.folha) { try { history.back(); } catch (e) { /* ignora */ } } }
    const cb = this.aoFechar; this.aoFechar = null; if (cb) cb();
  },
};

/* ============ rotas ============ */
const ROTAS = {};
const rolagem = {};
let hashAtual = '';

function irPara(h) { if (location.hash === '#' + h) rotear(); else location.hash = h; }

window.addEventListener('popstate', () => { if (!$('#folha').hidden) Folha.fechar(true); });

function rotear() {
  Folha.fechar(true);
  if (E.aoSair) { const f = E.aoSair; E.aoSair = null; try { f(); } catch (e) { console.error(e); } } /* grava o que ainda estava pendente na tela anterior */
  if (hashAtual) rolagem[hashAtual] = window.scrollY;
  let h = (location.hash || '').replace(/^#/, '') || 'inicio';
  const i = h.indexOf('-');
  let nome = i < 0 ? h : h.slice(0, i); const arg = i < 0 ? '' : h.slice(i + 1);
  if (E.leitor) sairDoLeitor();
  E.refresh = null; E.rota = { nome, arg };
  if (!ROTAS[nome]) nome = 'inicio';
  if ((nome === 'admin' || nome === 'rascunho') && !P.dono) { if (P.pronto) { history.replaceState(null, '', '#inicio'); nome = 'inicio'; } }
  if (nome === 'ler' && !/^ler-/.test(hashAtual)) E.voltarPara = hashAtual || 'biblioteca';
  hashAtual = h;
  document.body.classList.toggle('modo-leitura', nome === 'ler');
  if (nome !== 'ler') document.body.removeAttribute('data-rt');
  const ativa = { ler: 'biblioteca', rascunho: 'admin' }[nome] || nome;
  $$('#nav a').forEach(a => { if (a.dataset.r === ativa) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  ROTAS[nome](arg);
  if (nome !== 'ler') window.scrollTo(0, rolagem[h] || 0);
  const app = $('#app'); if (app && nome !== 'ler') app.focus({ preventScroll: true });
}

function atualizarChrome() {
  $('#nav-admin').hidden = !P.dono;
  const q = $('#quem'); q.hidden = !P.dono; q.innerHTML = P.dono ? '<b>Editor</b>' : '';
  const c = $('#cont-rasc'); const n = Lib.rasc.size; c.hidden = !(P.dono && n); c.textContent = n;
}

/* ============ listas ============ */
const listaTextos = () => [...Lib.textos.values()];
/* texto do catálogo, ou uma página avulsa do marxists.org que já foi aberta/favoritada */
function itemDe(id) {
  const t = Lib.textos.get(id); if (t) return t;
  if (id.startsWith('u.')) { const i = infoDoc(id); return { id, titulo: i.titulo, autor: i.autor, ano: i.ano, avulso: true }; }
  return null;
}
const rotaDeItem = t => (t.capitulos && t.capitulos.length ? '#obra-' : '#ler-') + t.id;

function htmlObra(t) {
  const fav = E.estado.fav.includes(t.id);
  const p = (E.estado.pos[t.id] || {}).f || 0;
  const marcas = [t.capitulos && t.capitulos.length ? `<span class="tag ex">${t.capitulos.length} capítulos</span>` : '', t.avulso ? '<span class="tag ex">página avulsa</span>' : ''].join('');
  const tags = (marcas || (t.temas || []).length)
    ? `<span class="tags">${marcas}${(t.temas || []).slice(0, 4).map(x => `<span class="tag">${esc(x)}</span>`).join('')}</span>` : '';
  const barra = p > 0.01 ? `<span class="prog" role="img" aria-label="${Math.round(p * 100)}% lido"><i style="width:${Math.round(p * 100)}%"></i></span>` : '';
  return `<li class="obra"><a href="${rotaDeItem(t)}"><span class="ano${t.ano ? '' : ' sem'}">${esc(t.ano || 's.d.')}</span><span><span class="t">${esc(t.titulo)}</span><span class="a">${esc(t.autor || 'Autor não informado')}</span>${tags}${barra}</span></a>` +
    `<button class="fav" type="button" data-fav="${esc(t.id)}" aria-pressed="${fav}" aria-label="${fav ? 'Tirar dos favoritos' : 'Favoritar'}">${ICONE.estrela}</button></li>`;
}

function filtrar(lista, f) {
  const q = fold(f.q.trim()).split(/\s+/).filter(Boolean);
  const r = lista.filter(t => {
    const alvo = fold([t.titulo, t.autor, t.ano, (t.temas || []).join(' ')].join(' '));
    return q.every(x => alvo.includes(x)) && (!f.autor || t.autor === f.autor) && (!f.tema || (t.temas || []).includes(f.tema));
  });
  const cmp = {
    recentes: (a, b) => (b.publicadoEm || 0) - (a.publicadoEm || 0),
    titulo: (a, b) => fold(a.titulo).localeCompare(fold(b.titulo), 'pt-BR'),
    autor: (a, b) => fold(a.autor || '~').localeCompare(fold(b.autor || '~'), 'pt-BR') || fold(a.titulo).localeCompare(fold(b.titulo), 'pt-BR'),
    ano: (a, b) => (parseInt(a.ano) || 9999) - (parseInt(b.ano) || 9999),
  }[f.ordem] || (() => 0);
  return r.sort(cmp);
}

function estadoBiblioteca() {
  if (Lib.textos.size) return '';
  if (Lib.erroRede === 'config') return `<div class="estado"><b>App sem repositório configurado</b>O arquivo <code>config.js</code> ainda tem os valores de exemplo. Veja o README para ligar o app ao seu repositório do GitHub.</div>`;
  if (!Lib.vivo && !Lib.lento) return `<p class="carregando">Abrindo a biblioteca…</p>`;
  if (Lib.lento && !Lib.vivo) return `<div class="estado"><b>Não consegui abrir a biblioteca</b>${esc(Lib.erroRede || 'Sem conexão.')}<br>Confira a internet. Os textos que você já abriu continuam disponíveis.<br><button class="btn" type="button" data-recarregar>Tentar de novo</button></div>`;
  return P.dono
    ? `<div class="estado"><b>Biblioteca vazia</b>Você ainda não publicou nenhum texto. Adicione um endereço do marxists.org, confira o rascunho e publique.<br><a class="btn" href="#admin-adicionar">Adicionar o primeiro texto</a></div>`
    : `<div class="estado"><b>Biblioteca vazia</b>O dono ainda não publicou nenhum texto. Enquanto isso, você pode abrir qualquer endereço do marxists.org na tela Início.</div>`;
}

document.addEventListener('click', e => { if (e.target.closest('[data-recarregar]')) { e.preventDefault(); Lib.lento = false; avisarMudanca(); carregarCatalogo(); } });

function avisoDesatualizado() {
  return Lib.desatualizado && Lib.textos.size ? '<p class="nota-topo">Mostrando a lista guardada neste aparelho. Ela atualiza quando a conexão voltar.</p>' : '';
}

document.addEventListener('click', e => {
  const b = e.target.closest('[data-fav]');
  if (!b) return;
  e.preventDefault();
  const id = b.dataset.fav; const f = E.estado.fav;
  const i = f.indexOf(id); if (i >= 0) f.splice(i, 1); else f.unshift(id);
  privGravar('estado', E.estado);
  aviso(i >= 0 ? 'Removido dos favoritos' : 'Adicionado aos favoritos');
  if (E.refresh) E.refresh();
  else b.setAttribute('aria-pressed', String(i < 0));
});

/* ============ Início ============ */
function telaInicio() {
  $('#app').innerHTML = `<div class="pagina">
    <div class="busca"><input id="q" type="search" placeholder="Buscar por título, autor ou tema" autocomplete="off" enterkeyhint="search" aria-label="Buscar na biblioteca"></div>
    <div id="busca-res" hidden></div>
    <div id="inicio-corpo" class="espaco-v"></div></div>`;
  const q = $('#q');
  q.addEventListener('input', () => {
    const v = q.value.trim(); const res = $('#busca-res');
    $('#inicio-corpo').hidden = !!v; res.hidden = !v;
    if (v) { const l = filtrar(listaTextos(), { q: v, autor: '', tema: '', ordem: 'recentes' }); res.innerHTML = l.length ? `<ul class="indice">${l.map(htmlObra).join('')}</ul>` : `<p class="estado">Nada encontrado para “${esc(v)}”.</p>`; }
  });
  E.refresh = pintarInicio; pintarInicio();
}

async function pintarInicio() {
  const c = $('#inicio-corpo'); if (!c) return;
  const textos = listaTextos();
  if (!textos.length) { c.innerHTML = avisoDesatualizado() + estadoBiblioteca() + blocoMia(); ligarBlocoMia(c); return; }
  const ultChave = (E.estado.rec || []).find(k => infoDoc(k));
  const ult = ultChave ? { ...infoDoc(ultChave), id: ultChave } : null;
  const pr = ult ? ((E.estado.pos[ult.id] || {}).f || 0) : 0;
  const recentes = [...textos].sort((a, b) => (b.publicadoEm || 0) - (a.publicadoEm || 0)).slice(0, 5);
  const favs = E.estado.fav.map(itemDe).filter(Boolean).slice(0, 5);
  const autores = new Set(textos.map(t => t.autor).filter(Boolean)).size;
  c.innerHTML = avisoDesatualizado() +
    (ult ? `<section><h2 class="secao">Continuar lendo</h2><a class="continuar" href="#ler-${esc(ult.id)}"><span class="t">${esc(ult.titulo)}</span><span class="a">${esc([ult.sub, ult.autor].filter(Boolean).join(' · '))}</span><span class="prog"><i style="width:${Math.round(pr * 100)}%"></i></span><span class="linha"><span>${Math.round(pr * 100)}% lido</span><span>Retomar de onde parou</span></span></a></section>` : '') +
    `<section><h2 class="secao">Adicionados recentemente <span class="esp"></span><a href="#biblioteca">Ver tudo (${textos.length})</a></h2><ul class="indice">${recentes.map(htmlObra).join('')}</ul></section>` +
    (favs.length ? `<section><h2 class="secao">Favoritos</h2><ul class="indice">${favs.map(htmlObra).join('')}</ul></section>` : '') +
    `<section id="ini-marcas"></section>` +
    blocoMia() + `<p class="rodape-leve">${textos.length} textos · ${autores} autores</p>`;
  ligarBlocoMia(c);
  const marcas = await todasMarcas();
  const caixa = $('#ini-marcas'); if (!caixa) return;
  const todas = marcas.flatMap(d => d.itens.map(h => ({ ...h, tid: d.id }))).sort((a, b) => (b.em || 0) - (a.em || 0)).slice(0, 3);
  if (!todas.length) { caixa.innerHTML = ''; return; }
  caixa.innerHTML = `<h2 class="secao">Suas marcações recentes <span class="esp"></span><a href="#marcacoes">Ver todas</a></h2>` +
    todas.map(h => { const t = infoDoc(h.tid); return `<button class="m-item" type="button" data-c="${esc(h.cor)}" data-ir="${esc(h.tid)}" data-h="${esc(h.id)}"><q>${esc(resumoTexto(h.txt, 200))}</q>${h.nota ? `<span class="nt">${esc(h.nota)}</span>` : ''}<span class="nt">${esc(t ? (t.sub ? t.sub + ' — ' : '') + t.titulo : 'Texto removido')}</span></button>`; }).join('');
}

const resumoTexto = (s, n) => (s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s);

const URL_MIA_PT = 'https://www.marxists.org/portugues/';
function blocoMia() {
  return `<section class="mia" id="mia-caixa"><h2 class="secao" style="margin-top:0">Ler direto do marxists.org</h2>
    <p>Cole o endereço de qualquer página do <b>Arquivo Marxista na Internet</b>. O texto é buscado na hora, e os links do site abrem aqui mesmo, com suas marcações.</p>
    <form class="mia-form" id="mia-form" autocomplete="off" novalidate><input id="mia-url" type="text" inputmode="url" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="https://www.marxists.org/portugues/…" aria-label="Endereço no marxists.org"><button class="btn" type="submit">Abrir</button></form>
    <div class="acoes"><a class="btn sec peq" href="#ler-${chaveDeUrl(URL_MIA_PT)}">Explorar marxists.org/portugues</a></div></section>`;
}
function ligarBlocoMia(raiz) {
  const f = $('#mia-form', raiz); if (!f) return;
  f.onsubmit = e => {
    e.preventDefault();
    const u = normalizarUrlMia($('#mia-url', f).value);
    if (!u) { aviso('Esse endereço não é do marxists.org'); return; }
    abrirUrlMia(u);
  };
}
/* abre uma página do marxists.org no leitor (com âncora opcional) */
function abrirUrlMia(url) {
  const [base, frag] = [semFragmento(url), url.includes('#') ? url.slice(url.indexOf('#') + 1) : ''];
  E.ancora = frag || null; E.irPara = null;
  irPara('ler-' + chaveParaUrl(base));
}

document.addEventListener('click', e => {
  const b = e.target.closest('[data-ir]');
  if (!b) return;
  E.irPara = b.dataset.h || null; irPara('ler-' + b.dataset.ir);
});

/* ============ Biblioteca ============ */
function telaBiblioteca() {
  $('#app').innerHTML = `<div class="pagina">
    <h1 class="titulo-pag">Biblioteca</h1>
    <div>
      <div class="busca"><input id="q" type="search" placeholder="Buscar por título, autor ou tema" autocomplete="off" enterkeyhint="search" aria-label="Buscar na biblioteca" value="${esc(E.filtro.q)}"></div>
      <div class="filtros">
        <select id="f-autor" aria-label="Filtrar por autor"></select>
        <select id="f-tema" aria-label="Filtrar por tema"></select>
        <select id="f-ordem" aria-label="Ordenar">
          <option value="recentes">Mais recentes</option><option value="titulo">Título (A–Z)</option><option value="autor">Autor (A–Z)</option><option value="ano">Ano (mais antigos)</option>
        </select>
      </div>
    </div>
    <div id="bib-lista"></div></div>`;
  $('#f-ordem').value = E.filtro.ordem;
  $('#q').addEventListener('input', e => { E.filtro.q = e.target.value; pintarLista(); });
  $('#f-autor').addEventListener('change', e => { E.filtro.autor = e.target.value; pintarLista(); });
  $('#f-tema').addEventListener('change', e => { E.filtro.tema = e.target.value; pintarLista(); });
  $('#f-ordem').addEventListener('change', e => { E.filtro.ordem = e.target.value; pintarLista(); });
  E.refresh = () => { pintarOpcoes(); pintarLista(); }; E.refresh();
}

function pintarOpcoes() {
  const sa = $('#f-autor'), st = $('#f-tema'); if (!sa) return;
  const textos = listaTextos();
  const autores = [...new Set(textos.map(t => t.autor).filter(Boolean))].sort((a, b) => fold(a).localeCompare(fold(b), 'pt-BR'));
  const temas = [...new Set(textos.flatMap(t => t.temas || []))].sort((a, b) => fold(a).localeCompare(fold(b), 'pt-BR'));
  if (E.filtro.autor && !autores.includes(E.filtro.autor)) E.filtro.autor = '';
  if (E.filtro.tema && !temas.includes(E.filtro.tema)) E.filtro.tema = '';
  sa.innerHTML = `<option value="">Todos os autores</option>` + autores.map(a => `<option value="${esc(a)}">${esc(a)}</option>`).join('');
  st.innerHTML = `<option value="">Todos os temas</option>` + temas.map(a => `<option value="${esc(a)}">${esc(a)}</option>`).join('');
  sa.value = E.filtro.autor; st.value = E.filtro.tema;
}

function pintarLista() {
  const alvo = $('#bib-lista'); if (!alvo) return;
  const todos = listaTextos();
  if (!todos.length) { alvo.innerHTML = avisoDesatualizado() + estadoBiblioteca(); return; }
  const l = filtrar(todos, E.filtro);
  alvo.innerHTML = avisoDesatualizado() + (l.length
    ? `<p class="rodape-leve" style="margin:0 0 6px">${l.length} de ${todos.length} textos</p><ul class="indice">${l.map(htmlObra).join('')}</ul>`
    : `<div class="estado"><b>Nada encontrado</b>Tente outro termo ou limpe os filtros.</div>`);
}

/* ============ Marcações (de todos os textos) ============ */
function telaMarcacoes() {
  const est = { cor: '', q: '' };
  $('#app').innerHTML = `<div class="pagina">
    <h1 class="titulo-pag">Marcações</h1>
    <p class="sub">Seus trechos marcados em todos os textos. Só você vê estas marcações.</p>
    <div class="busca"><input id="q" type="search" placeholder="Buscar nas marcações e notas" autocomplete="off" aria-label="Buscar nas marcações"></div>
    <div class="chips" id="chips-cor" role="group" aria-label="Filtrar por cor">
      <button class="chip" type="button" data-cor="" aria-pressed="true">Todas</button>
      ${Object.keys(COR_NOME).map(c => `<button class="chip" type="button" data-cor="${c}" aria-pressed="false"><span class="bolinha" data-c="${c}"></span>${COR_NOME[c]}</button>`).join('')}
    </div>
    <div id="m-lista"><p class="carregando">Carregando marcações…</p></div>
    <div class="acoes" id="m-export" hidden>
      <button class="btn sec" type="button" id="exp-md">Compartilhar (Markdown)</button>
      <button class="btn sec" type="button" id="exp-copiar">Copiar tudo</button>
    </div></div>`;
  let docs = [];
  const pintar = () => {
    const q = fold(est.q.trim());
    const grupos = docs.map(d => ({ d, t: infoDoc(d.id), itens: d.itens.filter(h => (!est.cor || h.cor === est.cor) && (!q || fold(h.txt + ' ' + (h.nota || '')).includes(q))).sort((a, b) => (a.ini || 0) - (b.ini || 0)) })).filter(g => g.itens.length);
    grupos.sort((a, b) => Math.max(...b.itens.map(h => h.em || 0)) - Math.max(...a.itens.map(h => h.em || 0)));
    const alvo = $('#m-lista'); if (!alvo) return;
    $('#m-export').hidden = !docs.length;
    if (!docs.length) { alvo.innerHTML = `<div class="estado"><b>Nenhuma marcação ainda</b>Abra um texto, segure o dedo sobre um trecho para selecioná-lo e toque em uma das cores.</div>`; return; }
    if (!grupos.length) { alvo.innerHTML = `<div class="estado"><b>Nada encontrado</b>Nenhuma marcação com esse filtro.</div>`; return; }
    alvo.innerHTML = grupos.map(g => `<section class="grupo-m" style="margin-top:22px"><h3>${g.t ? `<a href="#ler-${esc(g.d.id)}">${esc(g.t.titulo)}</a>` : 'Texto que não está mais na biblioteca'}</h3><span class="a">${esc(g.t ? [g.t.sub, g.t.autor].filter(Boolean).join(' · ') : '')} · ${g.itens.length} ${g.itens.length === 1 ? 'marcação' : 'marcações'}</span>` +
      g.itens.map(h => `<button class="m-item" type="button" data-c="${esc(h.cor)}" ${g.t ? `data-ir="${esc(g.d.id)}" data-h="${esc(h.id)}"` : ''}><q>${esc(resumoTexto(h.txt, 400))}</q>${h.nota ? `<span class="nt">Nota: ${esc(h.nota)}</span>` : ''}</button>`).join('') + '</section>').join('');
  };
  const md = () => {
    const linhas = ['# Minhas marcações — Leitor Marxista', ''];
    docs.forEach(d => {
      const t = infoDoc(d.id);
      linhas.push(`## ${t ? (t.sub ? t.sub + ' — ' : '') + t.titulo : 'Texto removido'}${t && t.autor ? ' — ' + t.autor : ''}`);
      if (t && t.url) linhas.push(`Fonte: ${t.url}`);
      linhas.push('');
      [...d.itens].sort((a, b) => (a.ini || 0) - (b.ini || 0)).forEach(h => {
        linhas.push('> ' + h.txt.replace(/\s*\n\s*/g, ' ') + ` (${COR_NOME[h.cor] || h.cor})`); if (h.nota) linhas.push('', 'Nota: ' + h.nota); linhas.push('');
      });
    });
    return linhas.join('\n');
  };
  $('#q').addEventListener('input', e => { est.q = e.target.value; pintar(); });
  $('#chips-cor').addEventListener('click', e => {
    const b = e.target.closest('.chip'); if (!b) return; est.cor = b.dataset.cor;
    $$('#chips-cor .chip').forEach(x => x.setAttribute('aria-pressed', String(x === b))); pintar();
  });
  $('#exp-md').addEventListener('click', () => baixar('minhas-marcacoes.md', md()));
  $('#exp-copiar').addEventListener('click', async () => aviso(await copiar(md()) ? 'Marcações copiadas' : 'Não consegui copiar neste aparelho'));
  E.refresh = pintar;
  todasMarcas().then(d => { docs = d; pintar(); });
}

/* o Android não deixa o app gravar arquivos soltos: oferece compartilhar (quando o aparelho permite) ou copiar */
async function baixar(nome, dados) {
  try {
    if (navigator.share) { await navigator.share({ title: nome, text: dados }); return; }
  } catch (e) { if (e && e.name === 'AbortError') return; }
  aviso(await copiar(dados) ? 'Copiado. Cole em um aplicativo de notas ou e-mail.' : 'Não consegui copiar neste aparelho');
}

Object.assign(ROTAS, { inicio: telaInicio, biblioteca: telaBiblioteca, marcacoes: telaMarcacoes });
