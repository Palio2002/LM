/* ============ ajustes: modo editor, dados do aparelho, sobre ============ */
function telaAjustes() {
  const app = $('#app');
  const pintar = async () => {
    if (E.rota.nome !== 'ajustes') return;
    const nPag = await IDB.varrer('pg:', false);
    if (E.rota.nome !== 'ajustes') return;
    const editor = P.dono
      ? `<p class="sub" style="margin:0 0 12px">Modo editor <b>ligado</b>${P.login ? ' (conta ' + esc(P.login) + ')' : ''}. Você vê a aba Admin e pode publicar no repositório <b>${esc(CFG.repo || '')}</b>.</p>
         <div class="acoes"><a class="btn" href="#admin">Abrir o Admin</a><button class="btn sec" id="aj-sair" type="button">Sair do modo editor</button></div>`
      : `<p class="sub" style="margin:0 0 12px">Só o dono da biblioteca precisa disto. O <b>token</b> é uma senha criada na sua conta do GitHub, que dá permissão de escrever no repositório <b>${esc(configOk() ? CFG.repo : '(não configurado)')}</b>. Sem ele, ninguém consegue adicionar ou alterar textos, nem usando este app.</p>
         <div class="campo"><label for="aj-token">Token do GitHub</label><input id="aj-token" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="github_pat_…"><span class="dica">Fica guardado só neste aparelho. Crie o token com acesso apenas a este repositório (README, passo 6).</span></div>
         <div class="acoes"><button class="btn" id="aj-entrar" type="button">Entrar no modo editor</button></div><p class="rodape-leve" id="aj-msg"></p>`;
    app.innerHTML = `<div class="pagina"><h1 class="titulo-pag">Ajustes</h1>
      <section class="zona"><h2 class="secao">Modo editor</h2>${editor}</section>
      <section class="zona"><h2 class="secao">Seus dados neste aparelho</h2>
        <p class="sub" style="margin:0 0 12px">Marcações, notas, favoritos e posição de leitura ficam só aqui; ninguém mais vê, nem o dono. Para trocar de aparelho, copie o backup e cole no outro.</p>
        <div class="acoes"><button class="btn sec" id="aj-bk" type="button">Copiar backup</button></div>
        <div class="campo" style="margin-top:12px"><label for="aj-bk-txt">Restaurar de um backup</label><textarea id="aj-bk-txt" rows="3" placeholder="Cole aqui o backup copiado em outro aparelho" spellcheck="false"></textarea></div>
        <div class="acoes"><button class="btn sec" id="aj-rest" type="button">Restaurar</button></div><p class="rodape-leve" id="aj-bk-msg"></p></section>
      <section class="zona"><h2 class="secao">Textos guardados</h2>
        <p class="sub" style="margin:0 0 12px">${nPag} página${nPag === 1 ? '' : 's'} do marxists.org guardada${nPag === 1 ? '' : 's'} neste aparelho para ler sem internet. Suas marcações não são apagadas.</p>
        <div class="acoes"><button class="btn sec" id="aj-limpar" type="button">Apagar textos guardados</button></div></section>
      <section class="zona"><h2 class="secao">Teste de conexão</h2>
        <p class="sub" style="margin:0 0 12px">Se um texto não abrir, toque aqui: o app tenta falar com o marxists.org e com o catálogo e mostra o resultado. Se pedirem ajuda, mostre este resultado.</p>
        <div class="acoes"><button class="btn sec" id="aj-diag" type="button">Testar conexão</button></div><pre class="diag" id="aj-diag-out" hidden></pre></section>
      <section class="zona"><h2 class="secao">Sobre</h2>
        <p class="sub" style="margin:0">Leitor Marxista${CFG.versao ? ' · versão ' + esc(CFG.versao) : ''}. Os textos são lidos ao vivo do <b>Arquivo Marxista na Internet</b> (marxists.org), obra de voluntários; cada página mostra o link e o crédito de origem. O app não tem anúncios, conta nem rastreamento: ele só conversa com o marxists.org e com o repositório do catálogo (github.com).</p>
        <p class="rodape-leve">Catálogo: ${Lib.textos.size} texto${Lib.textos.size === 1 ? '' : 's'}${Lib.atualizadoEm ? ', atualizado em ' + fmtData(Lib.atualizadoEm) : ''}${Lib.desatualizado ? ' (cópia guardada, sem conexão agora)' : ''}.</p></section></div>`;

    const ent = $('#aj-entrar');
    if (ent) ent.onclick = async () => {
      const m = $('#aj-msg'); ent.disabled = true; m.textContent = 'Conferindo o token…';
      try { await entrarModoEditor($('#aj-token').value); aviso('Modo editor ligado'); pintar(); }
      catch (e) { m.textContent = e.message || 'Não consegui entrar.'; ent.disabled = false; }
    };
    const sair = $('#aj-sair'); if (sair) sair.onclick = () => doisToques(sair, 'Toque de novo para sair', () => { sairDoModoEditor(); aviso('Você saiu do modo editor'); pintar(); });
    $('#aj-bk').onclick = async () => {
      const dados = {}; LS.chaves('p.').forEach(k => { dados[k] = LS.get(k, null); });
      await baixar('leitor-marxista-backup.json', JSON.stringify({ app: 'leitor-marxista-dados', versao: 1, em: new Date().toISOString(), dados }));
    };
    $('#aj-rest').onclick = () => {
      const m = $('#aj-bk-msg');
      try {
        const j = JSON.parse($('#aj-bk-txt').value);
        if (!j || j.app !== 'leitor-marxista-dados' || typeof j.dados !== 'object') throw new Error('Isto não parece um backup do Leitor Marxista.');
        let n = 0;
        for (const [k, v] of Object.entries(j.dados)) {
          if (!/^p\.(marcas_|estado$|prefs$)/.test(k) || !v || typeof v !== 'object') continue;
          const atual = LS.get(k, null);
          if (k === 'p.estado' && atual) { v.fav = [...new Set([...(atual.fav || []), ...(v.fav || [])])]; v.rec = [...new Set([...(v.rec || []), ...(atual.rec || [])])].slice(0, 30); v.pos = { ...(atual.pos || {}), ...(v.pos || {}) }; v.docs = { ...(atual.docs || {}), ...(v.docs || {}) }; v.em = agora(); LS.set(k, v); n++; continue; }
          if (!atual || (v.em || 0) >= (atual.em || 0)) { LS.set(k, v); n++; }
        }
        Promise.all([privLer('prefs', E.prefs), privLer('estado', E.estado)]).then(([pr, es]) => { E.prefs = { ...PADRAO_PREFS, ...pr }; E.estado = { fav: [], pos: {}, rec: [], docs: {}, ...es }; aplicarPrefs(); });
        m.textContent = n ? `Pronto: ${n} item${n === 1 ? '' : 's'} restaurado${n === 1 ? '' : 's'}.` : 'Nada novo para restaurar.';
      } catch (e) { m.textContent = e.message || 'Não consegui ler o backup.'; }
    };
    $('#aj-diag').onclick = async e => {
      const b = e.currentTarget; const out = $('#aj-diag-out'); b.disabled = true; out.hidden = false; out.textContent = 'Testando…';
      const linhas = [`Aparelho: ${Rede.nativo() ? 'app Android' : 'navegador'} · HTTP nativo: ${Rede.plugin() ? 'sim' : 'NÃO (modo reserva)'}`, `Repositório do catálogo: ${configOk() ? CFG.repo + ' (' + RAMO() + ')' : 'NÃO configurado'}`];
      try {
        const t0 = agora(); const r = await Rede.pedir({ url: URL_MIA_PT }); const d = decodificarBytes(r.bytes);
        const suspeito = /Ã[§£©³¡ª]|\uFFFD/.test(d.texto);
        linhas.push(`marxists.org: resposta ${r.status}, ${Math.round(r.bytes.length / 1024)} KB, ${d.cod}, ${agora() - t0} ms${suspeito ? ' · ATENÇÃO: acentos suspeitos' : ' · acentos ok'}`);
      } catch (er) { linhas.push('marxists.org: FALHOU — ' + er.message); }
      if (configOk()) {
        try { const r = await Rede.pedir({ url: urlRaw(CAMINHO_CAT()) + '?v=' + agora() }); const j = r.status === 200 ? Rede.json(r) : null; linhas.push(`Catálogo no GitHub: resposta ${r.status}${j && j.itens ? ', ' + j.itens.length + ' texto(s)' : r.status === 404 ? ' (ainda não existe: publique o primeiro texto)' : ''}`); }
        catch (er) { linhas.push('Catálogo no GitHub: FALHOU — ' + er.message); }
      }
      linhas.push(`Textos guardados: ${await IDB.varrer('pg:', false)} · Modo editor: ${P.dono ? 'ligado' : 'desligado'}`);
      out.textContent = linhas.join('\n'); b.disabled = false;
    };
    $('#aj-limpar').onclick = e => doisToques(e.currentTarget, 'Toque de novo para apagar', async () => {
      await IDB.varrer('pg:', true); memPag.clear(); aviso('Textos guardados apagados'); pintar();
    });
  };
  E.refresh = null; pintar();
}
ROTAS.ajustes = telaAjustes;
