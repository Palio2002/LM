/* ============ rede: HTTP nativo (sem CORS), decodificação de charset, páginas do marxists.org ============
   No aparelho, as chamadas passam pelo plugin CapacitorHttp (código nativo do Android), que não sofre
   o bloqueio de CORS do navegador. Fora do aparelho (testes) cai para fetch(). */

const MIA_RE = /(^|\.)marxists\.org$/i;
const LIMITE_PAGINA = 8 * 1048576;

function bytesDeBase64(b64) {
  const bin = atob(String(b64).replace(/\s/g, ''));
  const b = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
  return b;
}
function base64DeTexto(s) {
  const b = new TextEncoder().encode(s); let bin = '';
  for (let i = 0; i < b.length; i += 0x8000) bin += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
  return btoa(bin);
}
/* base64 de verdade (nunca contém < > espaços no meio…); HTML em texto puro falha neste teste */
function pareceBase64(s) { s = String(s).replace(/\s/g, ''); return s.length % 4 === 0 && /^[A-Za-z0-9+/]*={0,2}$/.test(s); }
const textoDeBase64 = b64 => new TextDecoder().decode(bytesDeBase64(b64));

/* bytes → texto, descobrindo o charset (BOM, UTF-8, cabeçalho HTTP, <meta>, senão windows-1252) */
function decodificarBytes(bytes, dica) {
  if (bytes[0] === 0xFF && bytes[1] === 0xFE) return { texto: new TextDecoder('utf-16le').decode(bytes), cod: 'utf-16le' };
  if (bytes[0] === 0xFE && bytes[1] === 0xFF) return { texto: new TextDecoder('utf-16be').decode(bytes), cod: 'utf-16be' };
  try { return { texto: new TextDecoder('utf-8', { fatal: true }).decode(bytes), cod: 'utf-8' }; } catch (e) { /* não é UTF-8 */ }
  const cab = new TextDecoder('latin1').decode(bytes.slice(0, 3000));
  const m = cab.match(/charset\s*=\s*["']?([\w-]+)/i);
  const cod = String(dica || (m && m[1]) || 'windows-1252').toLowerCase();
  try { return { texto: new TextDecoder(cod).decode(bytes), cod }; } catch (e) { return { texto: new TextDecoder('windows-1252').decode(bytes), cod: 'windows-1252' }; }
}

const Rede = {
  nativo() { try { return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); } catch (e) { return false; } },
  /* 1º: Capacitor.Plugins.CapacitorHttp; 2º: a ponte nativa direta (nativePromise); senão null (cai para fetch) */
  plugin() {
    try {
      const C = window.Capacitor; if (!C) return null;
      const H = C.Plugins && C.Plugins.CapacitorHttp;
      if (H && typeof H.request === 'function') return H;
      if (this.nativo() && typeof C.nativePromise === 'function') return { request: o => C.nativePromise('CapacitorHttp', 'request', o) };
    } catch (e) { /* sem plugin */ }
    return null;
  },

  /* sempre devolve os bytes da resposta; quem chama decide se é texto ou JSON */
  async pedir({ url, metodo = 'GET', cabecalhos = {}, dados, ms = 30000 }) {
    const falha = (msg, extra) => Object.assign(new Error(msg), { rede: true }, extra);
    const limite = new Promise((_, no) => setTimeout(() => no(falha('A conexão demorou demais. Tente de novo.')), ms + 2000));
    const H = this.plugin();
    try {
      if (H) {
        const r = await Promise.race([H.request({ url, method: metodo, headers: cabecalhos, data: dados, responseType: 'arraybuffer', connectTimeout: ms, readTimeout: ms }), limite]);
        const cab = {}; Object.entries(r.headers || {}).forEach(([k, v]) => { cab[k.toLowerCase()] = v; });
        let bytes;
        if (typeof r.data === 'string') bytes = pareceBase64(r.data) ? bytesDeBase64(r.data) : new TextEncoder().encode(r.data); /* texto puro (versões/plugins que ignoram arraybuffer) */
        else if (r.data instanceof ArrayBuffer) bytes = new Uint8Array(r.data);
        else if (r.data == null) bytes = new Uint8Array(0);
        else bytes = new TextEncoder().encode(JSON.stringify(r.data));
        return { status: r.status, cabecalhos: cab, bytes, url: r.url || url };
      }
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
      const r = await fetch(url, { method: metodo, headers: cabecalhos, body: dados === undefined ? undefined : JSON.stringify(dados), signal: ctl.signal });
      clearTimeout(t);
      const cab = {}; r.headers.forEach((v, k) => { cab[k.toLowerCase()] = v; });
      return { status: r.status, cabecalhos: cab, bytes: new Uint8Array(await r.arrayBuffer()), url: r.url || url };
    } catch (e) {
      if (e && e.rede) throw e;
      throw falha('Sem conexão com a internet, ou o site não respondeu.');
    }
  },
  texto(r) { return decodificarBytes(r.bytes, (String(r.cabecalhos['content-type'] || '').match(/charset=([\w-]+)/i) || [])[1]).texto; },
  json(r) { try { return JSON.parse(this.texto(r)); } catch (e) { return null; } },
};

/* aceita "marxists.org/portugues/…", "www.marxists.org/…", "http://…" e devolve https://… ou '' */
function normalizarUrlMia(s) {
  s = String(s || '').trim(); if (!s) return '';
  if (!/^[a-z][a-z0-9+.-]*:/i.test(s)) s = 'https://' + s.replace(/^\/+/, '');
  let u; try { u = new URL(s); } catch (e) { return ''; }
  if (!/^https?:$/.test(u.protocol) || !MIA_RE.test(u.hostname) || u.username || u.password) return '';
  u.protocol = 'https:'; u.port = '';
  return u.href;
}
const semFragmento = s => String(s).split('#')[0];
const chaveDeUrl = url => 'u.' + encodeURIComponent(semFragmento(url));

/* baixa uma página do marxists.org (só https e só marxists.org, inclusive depois de redirecionamentos) */
async function baixarPagina(url) {
  const u = normalizarUrlMia(url); if (!u) throw new Error('Este endereço não é do marxists.org.');
  const r = await Rede.pedir({ url: semFragmento(u), cabecalhos: { Accept: 'text/html,application/xhtml+xml,*/*;q=0.8' } });
  let final = u; try { const f = new URL(r.url || u); if (!MIA_RE.test(f.hostname) || f.protocol !== 'https:') throw new Error('x'); final = f.href; } catch (e) { throw new Error('O site redirecionou para fora do marxists.org. Por segurança, não abri.'); }
  if (r.status === 404 || r.status === 410) throw new Error('Página não encontrada no marxists.org (erro ' + r.status + '). Confira o endereço.');
  if (r.status < 200 || r.status >= 300) throw new Error('O marxists.org respondeu com erro ' + r.status + '. Tente de novo mais tarde.');
  if (r.bytes.length > LIMITE_PAGINA) throw new Error('Página grande demais (mais de 8 MB).');
  const tipo = String(r.cabecalhos['content-type'] || '');
  if (tipo && !/html|text\/plain|xml/i.test(tipo)) throw new Error('Este endereço não é uma página de texto (' + tipo.split(';')[0] + ').');
  const { texto, cod } = decodificarBytes(r.bytes, (tipo.match(/charset=([\w-]+)/i) || [])[1]);
  return { texto, cod, url: final, ehTxt: /text\/plain/i.test(tipo) };
}
