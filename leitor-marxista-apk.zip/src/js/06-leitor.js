/* ============ leitor ============ */
const FONTES = {
  literata: { nome: 'Serifada', css: '"Literata", "Noto Serif", Georgia, "Times New Roman", serif' },
  sans: { nome: 'Sem serifa', css: '"Public Sans", Roboto, system-ui, -apple-system, "Segoe UI", sans-serif' },
  hiper: { nome: 'Alta legibilidade', css: '"Atkinson Hyperlegible", "Public Sans", system-ui, sans-serif' },
  classica: { nome: 'Clássica', css: 'Georgia, "Times New Roman", serif' },
  maquina: { nome: 'Máquina de escrever', css: '"Courier Prime", "Courier New", monospace' },
};
const TEMAS_LEITURA = [['auto', 'Auto'], ['claro', 'Claro'], ['sepia', 'Sépia'], ['cinza', 'Cinza'], ['escuro', 'Escuro'], ['preto', 'Preto']];

function aplicarPrefs() {
  const p = E.prefs; const s = document.documentElement.style;
  s.setProperty('--r-fonte', (FONTES[p.fonte] || FONTES.literata).css);
  s.setProperty('--r-tam', p.tam + 'px'); s.setProperty('--r-lh', String(p.lh)); s.setProperty('--r-margem', p.margem + 'px');
  s.setProperty('--r-alinhar', p.alinhar); s.setProperty('--r-hifen', p.hifen ? 'auto' : 'manual');
  if (E.leitor) document.body.dataset.rt = p.tema;
}

const dentroDaRota = id => E.rota.nome === 'ler' && E.rota.arg === id;

/* resolve a chave da rota em {t, html, ...}: texto do catálogo, capítulo de uma obra ou página avulsa do marxists.org */
async function abrirDocumento(A) {
  if (A.tipo === 'cat') {
    const t = Lib.textos.get(A.id);
    if (!t) throw new Error('Este texto não está na biblioteca (foi removido, ou a lista ainda não carregou).');
    if (t.tipo !== 'ao-vivo') { /* o corpo vem do repositório: passa de novo pela limpeza, caso tenha sido adulterado */ const bruto = await corpoArquivo(t); return { t, html: limparHtml(new DOMParser().parseFromString(bruto, 'text/html').body, urlSegura(t.fonte)), obra: null, cap: 0, url: urlSegura(t.fonte) }; }
    if (t.capitulos && t.capitulos.length) {
      if (!A.cap) return { redirecionar: '#obra-' + t.id };
      const c = t.capitulos[A.cap - 1]; if (!c) throw new Error('Este capítulo não existe.');
      const pg = await lerPagina(c.u);
      return { t: { ...t, titulo: c.t, obraTitulo: t.titulo, fonte: c.u }, html: pg.html, pg, obra: t, cap: A.cap, url: c.u };
    }
    const pg = await lerPagina(t.url);
    return { t, html: pg.html, pg, obra: null, cap: 0, url: t.url };
  }
  const pg = await lerPagina(A.url); const m = pg.meta || {};
  return { t: { id: null, titulo: m.titulo || nomeDaUrl(A.url), autor: m.autor || '', ano: m.ano || '', fonte: A.url, credito: m.credito || '' }, html: pg.html, pg, obra: null, cap: 0, url: A.url, avulso: true };
}

async function esperarCatalogo(ms, id) {
  for (let i = 0; i < ms / 150 && !Lib.vivo && !Lib.lento && !(id ? Lib.textos.get(id) : Lib.textos.size); i++) await esperar(150);
}

async function telaLer(arg) {
  const app = $('#app');
  app.innerHTML = '<p class="carregando">Abrindo texto…</p>';
  document.body.dataset.rt = E.prefs.tema;
  const voltarBase = E.voltarPara || 'biblioteca';
  const falha = (titulo, msg) => `<div class="pagina"><div class="estado"><b>${esc(titulo)}</b>${esc(msg || '')}<br><a class="btn" href="#${esc(voltarBase)}">Voltar</a></div></div>`;
  const A = analisarChave(arg);
  if (A.tipo === 'invalida' || (A.tipo === 'url' && !A.url)) { app.innerHTML = falha('Endereço inválido', 'Só abro páginas do marxists.org.'); return; }
  if (A.tipo === 'cat' && !Lib.textos.get(A.id)) await esperarCatalogo(6000, A.id);
  if (!dentroDaRota(arg)) return;
  if (A.tipo === 'url') { await esperarCatalogo(2500); if (!dentroDaRota(arg)) return; const alt = chaveParaUrl(A.url); if (alt !== arg) { history.replaceState(null, '', '#ler-' + alt); rotear(); return; } }

  let doc;
  try { doc = await abrirDocumento(A); }
  catch (e) { if (!dentroDaRota(arg)) return; app.innerHTML = falha('Não consegui abrir o texto', e.message || ''); return; }
  if (!dentroDaRota(arg)) return;
  if (doc.redirecionar) { history.replaceState(null, '', doc.redirecionar); rotear(); return; }
  const { t, html, obra, cap } = doc; const id = arg;
  const voltar = obra ? 'obra-' + obra.id : voltarBase;
  const favId = obra ? obra.id : (t.id || arg);
  lembrarDoc(arg, { titulo: obra ? t.titulo : t.titulo, autor: t.autor, ano: t.ano });

  const fonteSegura = urlSegura(t.fonte);
  const fonteMia = /(^|\.)marxists\.org$/i.test((() => { try { return new URL(fonteSegura).hostname; } catch (e) { return ''; } })());
  const linhaMeta = [t.ano ? esc(t.ano) : '', fonteSegura ? `<a href="${esc(fonteSegura)}" target="_blank" rel="noopener noreferrer">${fonteMia ? 'Ver no marxists.org' : 'Ver fonte original'}</a>` : ''].filter(Boolean).join(' · ');
  const aviso0 = doc.pg && doc.pg.offline ? `<p class="nota-topo">Sem conexão com o marxists.org: mostrando a cópia guardada em ${esc(fmtData(doc.pg.em))}.</p>` : '';
  const caps = obra ? obra.capitulos : [];
  const navCaps = obra ? `<nav class="lnav" aria-label="Capítulos">${cap > 1 ? `<a href="#ler-${esc(obra.id)}.${cap - 1}" rel="prev">← ${esc(caps[cap - 2].t.slice(0, 40))}</a>` : '<span></span>'}<a href="#obra-${esc(obra.id)}" class="meio">Capítulos</a>${cap < caps.length ? `<a href="#ler-${esc(obra.id)}.${cap + 1}" rel="next">${esc(caps[cap].t.slice(0, 40))} →</a>` : '<span></span>'}</nav>` : '';
  app.innerHTML = `
    <div class="lbarra">
      <button class="ibtn" id="l-voltar" type="button" aria-label="Voltar">${ICONE.voltar}</button>
      <span class="tt">${esc(t.titulo)}</span>
      <button class="ibtn txt" id="l-aa" type="button" aria-label="Aparência do texto">Aa</button>
      <button class="ibtn" id="l-nav" type="button" aria-label="Sumário, marcações e busca no texto">${ICONE.lista}</button>
      <button class="ibtn" id="l-fav" type="button" aria-label="Favoritar" aria-pressed="${E.estado.fav.includes(favId)}">${ICONE.estrela}</button>
    </div>
    <div class="lprog"><i></i></div>
    <article class="lcorpo">
      <header class="lcab"><h1>${esc(t.titulo)}</h1>${(t.obraTitulo || t.autor) ? `<p class="au">${esc([t.obraTitulo, t.autor].filter(Boolean).join(' · '))}</p>` : ''}${linhaMeta ? `<p class="me">${linhaMeta}</p>` : ''}</header>
      ${aviso0}
      <div class="texto" id="texto"></div>
      ${navCaps}
      <footer class="lrod">${t.credito ? `<p>${esc(t.credito)}</p>` : ''}${fonteMia ? '<p>Texto do Arquivo Marxista na Internet (marxists.org), mantido por voluntários. Confira as condições de uso no site de origem.</p>' : (fonteSegura ? '<p>Confira as condições de uso no site de origem.</p>' : '')}</footer>
    </article>
    <button class="voltar-ponto" id="l-ponto" type="button" hidden>↩ Voltar ao ponto de leitura</button>`;
  const raiz = $('#texto'); raiz.innerHTML = html;

  const L = E.leitor = { id, t, raiz, marcas: [], orfas: [], ultimo: null, ponto: null, dobrado: null, sumario: null, url: doc.url || '', pg: doc.pg || null, obra, cap, avulso: !!doc.avulso };
  aplicarPrefs();
  $('#l-voltar').onclick = () => irPara(voltar);
  $('#l-aa').onclick = abrirAparencia;
  $('#l-nav').onclick = () => abrirNavegar();
  $('#l-fav').onclick = e => {
    const f = E.estado.fav; const i = f.indexOf(favId); if (i >= 0) f.splice(i, 1); else f.unshift(favId);
    if (!obra) lembrarDoc(favId, { titulo: t.titulo, autor: t.autor, ano: t.ano });
    privGravar('estado', E.estado); e.currentTarget.setAttribute('aria-pressed', String(i < 0)); aviso(i >= 0 ? 'Removido dos favoritos' : 'Adicionado aos favoritos');
  };
  $('#l-ponto').onclick = () => { if (L.ponto != null) window.scrollTo(0, L.ponto); $('#l-ponto').hidden = true; L.ponto = null; };
  raiz.addEventListener('click', aoTocarNoTexto);
  window.addEventListener('scroll', aoRolar, { passive: true });

  E.estado.rec = [id, ...(E.estado.rec || []).filter(x => x !== id)].slice(0, 30);
  privGravar('estado', E.estado);

  L.marcas = await carregarMarcas(id);
  if (!dentroDaRota(arg) || E.leitor !== L) return;
  redesenharMarcas();
  L.restaurando = true;
  const ancora = E.ancora; E.ancora = null;
  ['touchstart', 'wheel', 'keydown', 'pointerdown'].forEach(ev => window.addEventListener(ev, () => { L.tocou = true; }, { once: true, passive: true }));
  requestAnimationFrame(() => {
    const alvo = (E.irPara || ancora) ? null : ((E.estado.pos[id] || {}).b != null ? E.estado.pos[id] : null);
    if (E.irPara) { const h = E.irPara; E.irPara = null; irParaMarca(h, false); }
    else if (ancora) { try { const el = raiz.querySelector(`[id="${CSS.escape(ancora)}"],[name="${CSS.escape(ancora)}"]`); if (el) el.scrollIntoView({ block: 'start' }); } catch (e) { /* ignora */ } }
    else if (alvo) restaurarPosicao(alvo);
    /* o layout pode mudar quando as fontes e imagens terminam de carregar: refaz a posição, a menos que a pessoa já tenha mexido */
    const tardio = () => { if (E.leitor === L && !L.tocou && alvo) restaurarPosicao(alvo); };
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(tardio);
    setTimeout(() => { tardio(); L.restaurando = false; aoRolar(); }, 700);
    aoRolar();
  });
}

function sairDoLeitor() {
  const L = E.leitor; if (!L) return;
  salvarPosicao.agora();
  window.removeEventListener('scroll', aoRolar);
  esconderSelbar(); E.leitor = null;
  privDescarregar();
}

/* ---- posição de leitura e progresso ---- */
const BARRA_ALTA = 52;
function posicaoAtual() {
  const L = E.leitor; if (!L) return null;
  const kids = L.raiz.children; if (!kids.length) return null;
  const y = BARRA_ALTA - L.raiz.getBoundingClientRect().top;
  let lo = 0, hi = kids.length - 1;
  while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (kids[mid].offsetTop <= y) lo = mid; else hi = mid - 1; }
  const k = kids[lo];
  return { b: lo, d: k.offsetHeight ? Math.max(0, Math.min(1, (y - k.offsetTop) / k.offsetHeight)) : 0 };
}
function restaurarPosicao(p) {
  const L = E.leitor; if (!L || !p) return;
  const k = L.raiz.children[p.b]; if (!k) return;
  const topo = L.raiz.getBoundingClientRect().top + window.scrollY;
  window.scrollTo(0, Math.max(0, topo + k.offsetTop + (p.d || 0) * k.offsetHeight - BARRA_ALTA));
}
const salvarPosicao = debounce(() => {
  const L = E.leitor; if (!L || L.restaurando) return;
  const p = posicaoAtual(); if (!p) return;
  const alt = document.documentElement.scrollHeight - window.innerHeight;
  const f = alt > 0 ? Math.min(1, Math.max(0, window.scrollY / alt)) : 1;
  E.estado.pos[L.id] = { b: p.b, d: Math.round(p.d * 1000) / 1000, f: Math.round(f * 1000) / 1000 };
  const chaves = Object.keys(E.estado.pos); if (chaves.length > 300) delete E.estado.pos[chaves[0]];
  privGravar('estado', E.estado);
}, 1200);
function aoRolar() {
  const L = E.leitor; if (!L) return;
  const alt = document.documentElement.scrollHeight - window.innerHeight;
  const f = alt > 0 ? Math.min(1, Math.max(0, window.scrollY / alt)) : 0;
  const el = $('.lprog'); if (el) el.style.setProperty('--prog', f.toFixed(4));
  salvarPosicao();
}

/* ---- toques no texto: notas de rodapé e marcas ---- */
function aoTocarNoTexto(e) {
  const L = E.leitor; if (!L) return;
  const mia = e.target.closest('a[href^="http"]');
  if (mia) {
    const u = normalizarUrlMia(mia.getAttribute('href'));
    if (u) {
      e.preventDefault();
      const frag = u.includes('#') ? u.slice(u.indexOf('#') + 1) : '';
      if (L.url && semFragmento(u) === semFragmento(L.url)) { /* mesma página: só rola até a nota */
        let alvo = null; try { alvo = frag ? L.raiz.querySelector(`[id="${CSS.escape(decodeURIComponent(frag))}"]`) : null; } catch (err) { alvo = null; }
        if (alvo) { L.ponto = window.scrollY; $('#l-ponto').hidden = false; alvo.scrollIntoView({ block: 'start' }); }
      } else abrirUrlMia(u);
    }
    return;
  }
  const a = e.target.closest('a[href^="#"]');
  if (a) {
    e.preventDefault();
    let alvo = null;
    try { const id = decodeURIComponent(a.getAttribute('href').slice(1)); alvo = id ? L.raiz.querySelector(`[id="${CSS.escape(id)}"]`) : null; } catch (err) { alvo = null; }
    if (alvo) {
      L.ponto = window.scrollY; $('#l-ponto').hidden = false;
      alvo.scrollIntoView({ block: 'start' });
    }
    return;
  }
  const sel = window.getSelection();
  if (sel && !sel.isCollapsed) return;
  const m = e.target.closest('mark[data-h]');
  if (m) abrirMarca(m.dataset.h);
}

/* ---- marcação ---- */
function redesenharMarcas() {
  const L = E.leitor; if (!L) return;
  L.orfas = aplicarMarcas(L.raiz, L.marcas);
}
function persistirMarcas() { const L = E.leitor; if (L) gravarMarcas(L.id, L.marcas); }

function criarMarca(cor, nota) {
  const L = E.leitor; if (!L) return null;
  const r = L.ultimo;
  if (!r) { aviso('Selecione um trecho do texto primeiro'); return null; }
  const d = marcaDaSelecao(L.raiz, r);
  if (!d) { aviso('Selecione um trecho do texto primeiro'); return null; }
  if (d.erro) { aviso(d.erro); return null; }
  const h = { id: 'h' + novoId().slice(1), cor, ...d, nota: nota || '', em: agora() };
  L.marcas.push(h); persistirMarcas(); redesenharMarcas();
  const sel = window.getSelection(); if (sel) sel.removeAllRanges();
  L.ultimo = null; esconderSelbar();
  return h;
}

function irParaMarca(hid, piscar = true) {
  const L = E.leitor; if (!L) return;
  const m = L.raiz.querySelector(`mark[data-h="${CSS.escape(hid)}"]`);
  if (!m) { aviso('Não encontrei este trecho no texto. Ele pode ter sido alterado.'); return; }
  m.scrollIntoView({ block: 'center' });
  if (piscar) { m.classList.add('pisca'); setTimeout(() => m.classList.remove('pisca'), 1600); }
}

function citacao(txt) {
  const t = E.leitor.t;
  return `“${txt.replace(/\s+/g, ' ').trim()}” — ${[t.autor, t.obraTitulo, t.titulo].filter(Boolean).join(', ')}${t.ano ? ' (' + t.ano + ')' : ''}${t.fonte ? '. Fonte: ' + t.fonte : ''}`;
}

/* barra que aparece ao selecionar texto */
function mostrarSelbar() { $('#selbar').hidden = false; }
function esconderSelbar() { const b = $('#selbar'); if (b) b.hidden = true; }

document.addEventListener('selectionchange', debounce(() => {
  const L = E.leitor; if (!L) return;
  if (!$('#folha').hidden) return;
  const sel = window.getSelection();
  if (!sel || sel.isCollapsed || !sel.rangeCount) { esconderSelbar(); return; }
  const r = sel.getRangeAt(0);
  if (!L.raiz.contains(r.commonAncestorContainer)) { esconderSelbar(); return; }
  L.ultimo = r.cloneRange(); mostrarSelbar();
}, 140));

$('#selbar').addEventListener('pointerdown', e => { e.preventDefault(); });
$('#selbar').addEventListener('click', async e => {
  const L = E.leitor; if (!L) return;
  const cor = e.target.closest('[data-c]');
  if (cor) { criarMarca(cor.dataset.c); return; }
  const a = e.target.closest('[data-a]'); if (!a) return;
  if (a.dataset.a === 'citar') {
    const d = L.ultimo && marcaDaSelecao(L.raiz, L.ultimo);
    if (!d || d.erro) { aviso('Selecione um trecho do texto primeiro'); return; }
    aviso(await copiar(citacao(d.txt)) ? 'Citação copiada' : 'Não consegui copiar neste aparelho');
  } else if (a.dataset.a === 'nota') abrirNovaNota();
});

function seletorCores(atual) {
  return `<div class="chips" role="group" aria-label="Cor da marcação">${Object.keys(COR_NOME).map(c => `<button class="chip" type="button" data-cor="${c}" aria-pressed="${c === atual}"><span class="bolinha" data-c="${c}"></span>${COR_NOME[c]}</button>`).join('')}</div>`;
}
function ligarSeletorCores(el, aoMudar) {
  el.addEventListener('click', e => {
    const b = e.target.closest('[data-cor]'); if (!b) return;
    $$('[data-cor]', el).forEach(x => x.setAttribute('aria-pressed', String(x === b))); aoMudar(b.dataset.cor);
  });
}

function abrirNovaNota() {
  const L = E.leitor; if (!L || !L.ultimo) return;
  const d = marcaDaSelecao(L.raiz, L.ultimo); if (!d || d.erro) { aviso((d && d.erro) || 'Selecione um trecho do texto primeiro'); return; }
  let cor = 'a';
  Folha.abrir({
    titulo: 'Marcar com nota',
    html: `<blockquote class="m-item" data-c="a" style="cursor:default"><q>${esc(resumoTexto(d.txt, 300))}</q></blockquote>${seletorCores(cor)}
      <div class="campo"><label for="nota-t">Sua nota</label><textarea id="nota-t" rows="4" placeholder="Por que este trecho importa?"></textarea></div>
      <div class="acoes"><button class="btn" id="nota-ok" type="button">Salvar marcação</button></div>`,
    montar: el => {
      ligarSeletorCores($('.chips', el), c => { cor = c; $('.m-item', el).dataset.c = c; });
      $('#nota-ok', el).onclick = () => { const n = $('#nota-t', el).value.trim(); Folha.fechar(); criarMarca(cor, n); };
      setTimeout(() => $('#nota-t', el).focus(), 50);
    },
  });
}

function abrirMarca(hid) {
  const L = E.leitor; if (!L) return;
  const h = L.marcas.find(x => x.id === hid); if (!h) return;
  Folha.abrir({
    titulo: 'Marcação',
    html: `<blockquote class="m-item" data-c="${esc(h.cor)}" style="cursor:default"><q>${esc(resumoTexto(h.txt, 500))}</q></blockquote>${seletorCores(h.cor)}
      <div class="campo"><label for="nota-t">Nota</label><textarea id="nota-t" rows="4" placeholder="Escreva uma nota (opcional)">${esc(h.nota || '')}</textarea></div>
      <div class="acoes"><button class="btn" id="m-salvar" type="button">Salvar</button><button class="btn sec" id="m-citar" type="button">Copiar citação</button><button class="btn perigo" id="m-apagar" type="button">Apagar marcação</button></div>`,
    montar: el => {
      ligarSeletorCores($('.chips', el), c => { h.cor = c; $('.m-item', el).dataset.c = c; });
      $('#m-salvar', el).onclick = () => { h.nota = $('#nota-t', el).value.trim(); h.em = agora(); persistirMarcas(); redesenharMarcas(); Folha.fechar(); };
      $('#m-citar', el).onclick = async () => aviso(await copiar(citacao(h.txt)) ? 'Citação copiada' : 'Não consegui copiar neste aparelho');
      $('#m-apagar', el).onclick = e => doisToques(e.currentTarget, 'Toque de novo para apagar', () => {
        L.marcas = L.marcas.filter(x => x.id !== hid); persistirMarcas(); redesenharMarcas(); Folha.fechar(); aviso('Marcação apagada');
      });
    },
    aoFechar: () => { const n = $('#nota-t'); if (n && E.leitor === L && L.marcas.includes(h) && h.nota !== n.value.trim()) { h.nota = n.value.trim(); persistirMarcas(); redesenharMarcas(); } },
  });
}

/* ---- sumário, marcações do texto e busca dentro do texto ---- */
function rangeDe(raiz, ini, fim) {
  const { nos } = mapaTexto(raiz); const r = document.createRange();
  let ok1 = false, ok2 = false;
  for (const x of nos) {
    if (!ok1 && ini >= x.s && ini < x.e) { r.setStart(x.n, ini - x.s); ok1 = true; }
    if (!ok2 && fim > x.s && fim <= x.e) { r.setEnd(x.n, fim - x.s); ok2 = true; }
    if (ok1 && ok2) break;
  }
  return ok1 && ok2 ? r : null;
}

function abrirNavegar(aba) {
  const L = E.leitor; if (!L) return;
  Folha.abrir({
    titulo: L.t.titulo.length > 28 ? 'Neste texto' : L.t.titulo,
    inicial: aba || 'sumario',
    abas: [
      ...(L.obra ? [{ id: 'capitulos', rotulo: 'Capítulos', montar: el => {
        const caps = L.obra.capitulos;
        el.innerHTML = `<div class="toc">${caps.map((c, i) => `<a href="#ler-${esc(L.obra.id)}.${i + 1}" class="n1"${i + 1 === L.cap ? ' aria-current="true" style="font-weight:700"' : ''}>${i + 1}. ${esc(c.t)}</a>`).join('')}</div>`;
      } }] : []),
      { id: 'sumario', rotulo: 'Sumário', montar: el => {
        const hs = $$('h1,h2,h3,h4', L.raiz);
        if (!hs.length) { el.innerHTML = '<p class="rodape-leve">Este texto não tem títulos internos para listar.</p>'; return; }
        hs.forEach((h, i) => { if (!h.id) h.id = 'sm-' + i; });
        const nivel = n => Math.min(3, Math.max(1, parseInt(n.tagName[1]) - (Math.min(...hs.map(x => parseInt(x.tagName[1]))) - 1)));
        el.innerHTML = `<div class="toc">${hs.map(h => `<a href="#" class="n${nivel(h)}" data-id="${esc(h.id)}">${esc(h.textContent.replace(/\s+/g, ' ').trim().slice(0, 140))}</a>`).join('')}</div>`;
        el.onclick = e => { const a = e.target.closest('a[data-id]'); if (!a) return; e.preventDefault(); const alvo = L.raiz.querySelector(`[id="${CSS.escape(a.dataset.id)}"]`); Folha.fechar(); if (alvo) alvo.scrollIntoView({ block: 'start' }); };
      } },
      { id: 'marcas', rotulo: `Marcações (${L.marcas.length})`, montar: el => {
        if (!L.marcas.length) { el.innerHTML = '<p class="rodape-leve">Você ainda não marcou nada neste texto. Selecione um trecho e toque numa cor.</p>'; return; }
        const ord = [...L.marcas].sort((a, b) => a.ini - b.ini);
        el.innerHTML = ord.map(h => `<button class="m-item" type="button" data-c="${esc(h.cor)}" data-h="${esc(h.id)}"><q>${esc(resumoTexto(h.txt, 220))}</q>${h.nota ? `<span class="nt">${esc(h.nota)}</span>` : ''}${L.orfas.includes(h.id) ? '<span class="orf">Trecho não encontrado: o texto pode ter sido alterado.</span>' : ''}</button>`).join('');
        el.onclick = e => { const b = e.target.closest('[data-h]'); if (!b) return; Folha.fechar(); irParaMarca(b.dataset.h); };
      } },
      { id: 'sobre', rotulo: 'Sobre', montar: el => {
        const pg = L.pg;
        el.innerHTML = `${urlSegura(L.url) ? `<p style="margin:0 0 10px"><b>Origem</b><br><a href="${esc(urlSegura(L.url))}" target="_blank" rel="noopener noreferrer" style="word-break:break-all">${esc(urlSegura(L.url))}</a></p>` : ''}
          ${pg ? `<p class="rodape-leve">Cópia guardada neste aparelho em ${esc(fmtData(pg.em))}${pg.offline ? ' (sem conexão agora)' : ''}. O texto vem do marxists.org; se ele for corrigido lá, toque em atualizar.</p><div class="acoes"><button class="btn sec" id="s-atualizar" type="button">Atualizar do site</button></div>` : '<p class="rodape-leve">Texto guardado na biblioteca do dono.</p>'}
          ${P.dono && L.url && L.avulso ? `<div class="acoes" style="margin-top:12px"><button class="btn" id="s-rascunho" type="button">Criar rascunho desta página</button></div><p class="rodape-leve">Modo editor: leva esta página para a área de rascunhos, onde você confere antes de publicar na biblioteca.</p>` : ''}
          ${L.t.credito ? `<p class="rodape-leve">${esc(L.t.credito)}</p>` : ''}`;
        const rb = $('#s-rascunho', el);
        if (rb) rb.onclick = async () => { rb.disabled = true; try { const rid = await criarRascunhoDeUrl(L.url); Folha.fechar(true); irPara('rascunho-' + rid); } catch (e) { aviso(e.message || 'Não consegui criar o rascunho', 4000); rb.disabled = false; } };
        const b = $('#s-atualizar', el);
        if (b) b.onclick = async () => {
          b.disabled = true; b.textContent = 'Atualizando…';
          try { await lerPagina(L.url, { forcar: true }); Folha.fechar(); rotear(); aviso('Texto atualizado'); }
          catch (e) { aviso(e.message || 'Não consegui atualizar', 4000); b.disabled = false; b.textContent = 'Atualizar do site'; }
        };
      } },
      { id: 'busca', rotulo: 'Buscar', montar: el => {
        el.innerHTML = `<div class="busca"><input id="bt-q" type="search" placeholder="Buscar neste texto" autocomplete="off" aria-label="Buscar neste texto"></div><div id="bt-res" class="achados" style="margin-top:10px"></div>`;
        const res = $('#bt-res', el);
        $('#bt-q', el).addEventListener('input', debounce(ev => {
          const q = fold(ev.target.value.trim());
          if (q.length < 2) { res.innerHTML = ''; return; }
          if (!L.dobrado) L.dobrado = fold(L.raiz.textContent);
          const completo = L.raiz.textContent; const ach = []; let k = -1;
          while ((k = L.dobrado.indexOf(q, k + 1)) >= 0 && ach.length < 200) ach.push(k);
          if (!ach.length) { res.innerHTML = '<p class="rodape-leve">Nada encontrado.</p>'; return; }
          res.innerHTML = `<p class="rodape-leve">${ach.length}${ach.length === 200 ? '+' : ''} ocorrências</p>` + ach.map(p => {
            const a = Math.max(0, p - 40), b = Math.min(completo.length, p + q.length + 60);
            return `<button type="button" data-p="${p}" data-n="${q.length}">${a > 0 ? '…' : ''}${esc(completo.slice(a, p))}<mark>${esc(completo.slice(p, p + q.length))}</mark>${esc(completo.slice(p + q.length, b))}${b < completo.length ? '…' : ''}</button>`;
          }).join('');
        }, 250));
        res.onclick = e => {
          const b = e.target.closest('[data-p]'); if (!b) return;
          const p = +b.dataset.p, n = +b.dataset.n; Folha.fechar();
          const r = rangeDe(L.raiz, p, p + n); if (!r) return;
          const caixa = r.getBoundingClientRect(); window.scrollTo(0, Math.max(0, window.scrollY + caixa.top - window.innerHeight / 3));
          const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r);
        };
        setTimeout(() => $('#bt-q', el).focus(), 60);
      } },
    ],
  });
}

/* ---- aparência do texto ---- */
function mudarPrefs(fn) {
  const p = posicaoAtual();
  fn(); privGravar('prefs', E.prefs); aplicarPrefs();
  if (p) requestAnimationFrame(() => restaurarPosicao(p));
}

function abrirAparencia() {
  const pr = E.prefs;
  Folha.abrir({
    titulo: 'Aparência do texto',
    html: `
      <div class="ctrl"><span>Tamanho da letra <output id="v-tam">${pr.tam} px</output></span>
        <div class="acoes" style="flex-wrap:nowrap;align-items:center"><button class="btn sec peq" type="button" data-passo="-1" aria-label="Diminuir letra">A−</button><input type="range" id="a-tam" min="14" max="34" step="1" value="${pr.tam}" style="flex:1"><button class="btn sec peq" type="button" data-passo="1" aria-label="Aumentar letra">A+</button></div></div>
      <div class="ctrl"><span>Fonte</span><div class="opcoes" id="a-fontes">${Object.entries(FONTES).map(([k, f]) => `<button class="opcao" type="button" data-fonte="${k}" aria-pressed="${pr.fonte === k}" style="font-family:${esc(f.css)}">${esc(f.nome)}</button>`).join('')}</div></div>
      <div class="ctrl"><span>Cores de leitura</span><div class="opcoes" id="a-temas">${TEMAS_LEITURA.map(([k, n]) => `<button class="opcao tema" type="button" data-tema="${k}" aria-pressed="${pr.tema === k}">${n}</button>`).join('')}</div></div>
      <div class="ctrl"><span>Espaço entre linhas <output id="v-lh">${Number(pr.lh).toFixed(1)}</output></span><input type="range" id="a-lh" min="1.3" max="2.2" step="0.1" value="${pr.lh}"></div>
      <div class="ctrl"><span>Margens <output id="v-margem">${pr.margem} px</output></span><input type="range" id="a-margem" min="8" max="48" step="2" value="${pr.margem}"></div>
      <div class="ctrl"><span>Alinhamento</span><div class="opcoes" id="a-alinhar"><button class="opcao" type="button" data-alinhar="left" aria-pressed="${pr.alinhar === 'left'}">À esquerda</button><button class="opcao" type="button" data-alinhar="justify" aria-pressed="${pr.alinhar === 'justify'}">Justificado</button><button class="opcao" type="button" id="a-hifen" aria-pressed="${!!pr.hifen}">Separar sílabas</button></div></div>
      <button class="btn sec" id="a-reset" type="button">Restaurar padrão</button>`,
    montar: el => {
      const marcar = (cont, attr, val) => $$('[' + attr + ']', cont).forEach(b => b.setAttribute('aria-pressed', String(b.getAttribute(attr) === String(val))));
      const tam = v => { v = Math.min(34, Math.max(14, v)); mudarPrefs(() => { E.prefs.tam = v; }); $('#a-tam', el).value = v; $('#v-tam', el).textContent = v + ' px'; };
      $('#a-tam', el).oninput = e => tam(+e.target.value);
      $$('[data-passo]', el).forEach(b => { b.onclick = () => tam(E.prefs.tam + (+b.dataset.passo)); });
      $('#a-fontes', el).onclick = e => { const b = e.target.closest('[data-fonte]'); if (!b) return; mudarPrefs(() => { E.prefs.fonte = b.dataset.fonte; }); marcar($('#a-fontes', el), 'data-fonte', b.dataset.fonte); };
      $('#a-temas', el).onclick = e => { const b = e.target.closest('[data-tema]'); if (!b) return; mudarPrefs(() => { E.prefs.tema = b.dataset.tema; }); marcar($('#a-temas', el), 'data-tema', b.dataset.tema); };
      $('#a-lh', el).oninput = e => { mudarPrefs(() => { E.prefs.lh = +e.target.value; }); $('#v-lh', el).textContent = (+e.target.value).toFixed(1); };
      $('#a-margem', el).oninput = e => { mudarPrefs(() => { E.prefs.margem = +e.target.value; }); $('#v-margem', el).textContent = e.target.value + ' px'; };
      $('#a-alinhar', el).onclick = e => {
        const b = e.target.closest('button'); if (!b) return;
        if (b.id === 'a-hifen') { mudarPrefs(() => { E.prefs.hifen = !E.prefs.hifen; }); b.setAttribute('aria-pressed', String(!!E.prefs.hifen)); return; }
        mudarPrefs(() => { E.prefs.alinhar = b.dataset.alinhar; }); marcar($('#a-alinhar', el), 'data-alinhar', b.dataset.alinhar); $('#a-hifen', el).setAttribute('aria-pressed', String(!!E.prefs.hifen));
      };
      $('#a-reset', el).onclick = () => { mudarPrefs(() => { E.prefs = { ...PADRAO_PREFS }; }); Folha.fechar(); abrirAparencia(); };
    },
  });
}

document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') { if (E.leitor) salvarPosicao.agora(); privDescarregar(); } });
window.addEventListener('pagehide', () => { if (E.leitor) salvarPosicao.agora(); privDescarregar(); });

ROTAS.ler = telaLer;
