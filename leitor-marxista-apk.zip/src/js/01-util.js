/* ============ utilidades ============ */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const esperar = ms => new Promise(r => setTimeout(r, ms));
const agora = () => Date.now();
const novoId = () => 't' + Math.random().toString(36).slice(2, 8) + agora().toString(36).slice(-4);
const debounce = (fn, ms) => { let t; const f = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; f.agora = (...a) => { clearTimeout(t); return fn(...a); }; return f; };
const fmtData = ts => { try { return new Date(ts).toLocaleDateString('pt-BR'); } catch (e) { return ''; } };
const kb = n => n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(0) + ' KB' : (n / 1048576).toFixed(1) + ' MB';

/* minúsculas e sem acento, mantendo o mesmo comprimento do texto original (serve para achar trechos) */
function fold(s) {
  let o = '';
  for (const ch of String(s)) {
    if (ch.length > 1) { o += ch; continue; }
    const b = ch.normalize('NFD')[0];
    const l = b.toLowerCase();
    o += l.length === 1 ? l : b;
  }
  return o;
}

const LS = {
  get(k, d) { try { const v = localStorage.getItem('lm.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('lm.' + k, JSON.stringify(v)); return true; } catch (e) { return false; } },
  del(k) { try { localStorage.removeItem('lm.' + k); } catch (e) { /* ignora */ } },
  chaves(prefixo) { try { return Object.keys(localStorage).filter(k => k.startsWith('lm.' + prefixo)).map(k => k.slice(3)); } catch (e) { return []; } },
};

/* cópia local dos textos para ler sem internet */
const IDB = (() => {
  let p;
  const abrir = () => p || (p = new Promise((ok, no) => {
    try {
      const r = indexedDB.open('leitor-marxista', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('kv');
      r.onsuccess = () => ok(r.result);
      r.onerror = () => no(r.error);
    } catch (e) { no(e); }
  }));
  const tx = async (modo, f) => {
    const db = await abrir();
    return new Promise((ok, no) => {
      const t = db.transaction('kv', modo); const q = f(t.objectStore('kv'));
      t.oncomplete = () => ok(q && q.result); t.onerror = () => no(t.error);
    });
  };
  return {
    get: k => tx('readonly', s => s.get(k)).catch(() => undefined),
    set: (k, v) => tx('readwrite', s => s.put(v, k)).catch(() => { }),
    del: k => tx('readwrite', s => s.delete(k)).catch(() => { }),
    /* apaga (ou só conta) as chaves que começam com o prefixo */
    async varrer(prefixo, apagar) {
      try {
        const db = await abrir();
        return await new Promise(ok => {
          const t = db.transaction('kv', 'readwrite'); const q = t.objectStore('kv').openCursor(); let n = 0;
          q.onsuccess = () => { const c = q.result; if (!c) return; if (String(c.key).startsWith(prefixo)) { n++; if (apagar) c.delete(); } c.continue(); };
          t.oncomplete = () => ok(n); t.onerror = () => ok(n);
        });
      } catch (e) { return 0; }
    },
  };
})();

function aviso(msg, ms = 2600) {
  const el = $('#aviso'); el.textContent = msg; el.hidden = false;
  clearTimeout(aviso.t); aviso.t = setTimeout(() => (el.hidden = true), ms);
}

/* botão de dois toques: o primeiro arma, o segundo executa */
function doisToques(btn, rotuloArmado, fn) {
  if (btn.dataset.armado) { clearTimeout(btn._t); delete btn.dataset.armado; btn.classList.remove('armado'); btn.textContent = btn._orig; fn(); return; }
  btn._orig = btn.textContent; btn.dataset.armado = '1'; btn.classList.add('armado'); btn.textContent = rotuloArmado;
  btn._t = setTimeout(() => { delete btn.dataset.armado; btn.classList.remove('armado'); btn.textContent = btn._orig; }, 4000);
}

async function copiar(texto) {
  try { await navigator.clipboard.writeText(texto); return true; } catch (e) {
    try {
      const t = document.createElement('textarea');
      t.value = texto; t.style.cssText = 'position:fixed;opacity:0;top:0;left:0'; document.body.appendChild(t); t.select();
      const ok = document.execCommand('copy'); t.remove(); return ok;
    } catch (e2) { return false; }
  }
}

const ICONE = {
  estrela: '<svg class="estrela" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/></svg>',
  voltar: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>',
  fechar: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  lista: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/></svg>',
};

const COR_NOME = { a: 'Amarelo', v: 'Verde', z: 'Azul', r: 'Rosa' };

/* só links http(s) viram href; qualquer outra coisa (javascript:, data:…) vira vazio */
const urlSegura = u => { try { const x = new URL(String(u || '')); return /^https?:$/.test(x.protocol) ? x.href : ''; } catch (e) { return ''; } };
