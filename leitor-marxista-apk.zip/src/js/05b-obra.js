/* ============ obra com capítulos ============ */
function telaObra(id) {
  const app = $('#app');
  let baixando = false;
  const dentro = () => E.rota.nome === 'obra' && E.rota.arg === id;
  const pintar = async () => {
    if (!dentro()) return;
    const t = Lib.textos.get(id);
    if (!t) {
      app.innerHTML = Lib.vivo || Lib.lento
        ? `<div class="pagina"><div class="estado"><b>Obra não encontrada</b>Ela pode ter sido removida da biblioteca.<br><a class="btn" href="#biblioteca">Voltar à biblioteca</a></div></div>`
        : '<p class="carregando">Abrindo a obra…</p>';
      return;
    }
    const caps = t.capitulos || [];
    if (!caps.length) { history.replaceState(null, '', '#ler-' + id); rotear(); return; }
    const pos = E.estado.pos || {};
    const frac = i => (pos[id + '.' + (i + 1)] || {}).f || 0;
    const ult = (E.estado.rec || []).find(k => k.startsWith(id + '.'));
    const prox = ult ? Math.min(caps.length, +ult.split('.')[1]) : 1;
    const guardadas = await Promise.all(caps.map(c => IDB.get('pg:' + semFragmento(c.u))));
    if (!dentro()) return;
    const nGuard = guardadas.filter(Boolean).length;
    app.innerHTML = `<div class="pagina">
      <div><a href="#biblioteca" style="font-size:.86rem;font-weight:600">← Biblioteca</a><h1 class="titulo-pag" style="margin-top:8px">${esc(t.titulo)}</h1>
      <p class="sub">${esc([t.autor, t.ano].filter(Boolean).join(' · '))}${t.credito ? '<br>' + esc(t.credito) : ''}</p></div>
      <div class="acoes"><a class="btn" href="#ler-${esc(id)}.${prox}">${ult ? 'Continuar: ' + esc(caps[prox - 1].t.slice(0, 40)) : 'Começar a ler'}</a>
        <button class="btn sec" id="ob-offline" type="button">${nGuard === caps.length ? 'Tudo guardado ✓' : 'Guardar para ler sem internet'}</button></div>
      <p class="rodape-leve" id="ob-estado">${nGuard}/${caps.length} capítulos guardados neste aparelho.</p>
      <ol class="caps">${caps.map((c, i) => `<li><a href="#ler-${esc(id)}.${i + 1}"><span class="n">${i + 1}</span><span class="t">${esc(c.t)}</span><span class="st">${frac(i) > 0.95 ? '<b>lido</b>' : frac(i) > 0.02 ? Math.round(frac(i) * 100) + '%' : ''}${guardadas[i] ? '<i class="off" title="Guardado neste aparelho"></i>' : ''}</span></a></li>`).join('')}</ol>
      <p class="rodape-leve">${t.url ? `<a href="#ler-${chaveDeUrl(t.url)}">Página inicial da obra no marxists.org</a> · ` : ''}${urlSegura(t.fonte) ? `<a href="${esc(urlSegura(t.fonte))}" target="_blank" rel="noopener noreferrer">Abrir no navegador</a>` : ''}</p>
      <p class="rodape-leve">Texto do Arquivo Marxista na Internet (marxists.org), mantido por voluntários. Confira as condições de uso no site de origem.</p></div>`;
    $('#ob-offline').onclick = async e => {
      if (baixando) return; baixando = true; e.currentTarget.disabled = true;
      let feitos = 0, falhas = 0;
      for (let i = 0; i < caps.length && dentro(); i++) {
        const st = $('#ob-estado'); if (st) st.textContent = `Guardando ${i + 1}/${caps.length}…`;
        try { const ja = await IDB.get('pg:' + semFragmento(caps[i].u)); if (!ja) { await lerPagina(caps[i].u); await esperar(700); } feitos++; } catch (er) { falhas++; }
      }
      baixando = false;
      if (dentro()) { aviso(falhas ? `${feitos} guardados, ${falhas} falharam. Tente de novo.` : 'Obra guardada neste aparelho'); pintar(); }
    };
  };
  E.refresh = pintar; pintar();
}
ROTAS.obra = telaObra;
