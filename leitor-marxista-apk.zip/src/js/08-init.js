/* ============ partida ============ */
async function iniciar() {
  aplicarPrefs();
  ouvintes.add(() => { atualizarChrome(); if (E.refresh) E.refresh(); });
  window.addEventListener('hashchange', rotear);
  $('#folha-x').onclick = () => Folha.fechar();
  $('#fundo-folha').onclick = () => Folha.fechar();
  document.addEventListener('keydown', e => { if (e.key === 'Escape') Folha.fechar(); });
  /* ao voltar para o app depois de um tempo, confere se há novidades no catálogo */
  let ultimaVez = agora();
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    if (agora() - ultimaVez > 3 * 60000) { ultimaVez = agora(); carregarCatalogo(); }
  });

  const [pr, es] = await Promise.all([privLer('prefs', E.prefs), privLer('estado', E.estado), carregarRascunhos()]);
  E.prefs = { ...PADRAO_PREFS, ...pr }; E.estado = { fav: [], pos: {}, rec: [], docs: {}, ...es };
  aplicarPrefs();
  await revalidarEditor();
  P.pronto = true;
  atualizarChrome();
  rotear();
  carregarCatalogo();
}
iniciar();
