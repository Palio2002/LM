/* ============ motor de marcação (grifos) ============
   Cada marca guarda o trecho, o contexto ao redor e a posição em caracteres dentro do texto.
   Se o texto mudar, a marca é reencontrada pelo trecho; se não achar, vira "órfã" e continua na lista. */

function mapaTexto(raiz) {
  const nos = []; let pos = 0;
  const w = document.createTreeWalker(raiz, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = w.nextNode())) { const len = n.nodeValue.length; nos.push({ n, s: pos, e: pos + len }); pos += len; }
  return { nos, total: pos };
}

function offsetEm(raiz, no, off) {
  const r = document.createRange();
  r.selectNodeContents(raiz);
  try { r.setEnd(no, off); } catch (e) { return -1; }
  return r.toString().length;
}

function limparMarcas(raiz) {
  $$('mark[data-h]', raiz).forEach(m => {
    const p = m.parentNode; while (m.firstChild) p.insertBefore(m.firstChild, m); p.removeChild(m);
  });
  raiz.normalize();
}

function resolverMarca(completo, h) {
  if (completo.slice(h.ini, h.fim) === h.txt) return [h.ini, h.fim];
  const pre = h.pre || '', suf = h.suf || '';
  const i = (pre || suf) ? completo.indexOf(pre + h.txt + suf) : -1;
  if (i >= 0) return [i + pre.length, i + pre.length + h.txt.length];
  let melhor = -1, dist = Infinity, k = -1;
  while ((k = completo.indexOf(h.txt, k + 1)) >= 0) { const d = Math.abs(k - h.ini); if (d < dist) { dist = d; melhor = k; } }
  return melhor >= 0 ? [melhor, melhor + h.txt.length] : null;
}

/* desenha todas as marcas; devolve os ids das que não foram encontradas */
function aplicarMarcas(raiz, itens) {
  limparMarcas(raiz);
  const { nos } = mapaTexto(raiz);
  const completo = nos.map(x => x.n.nodeValue).join('');
  const res = []; const orfas = [];
  for (const h of itens) { const r = resolverMarca(completo, h); if (r) res.push({ h, s: r[0], e: r[1] }); else orfas.push(h.id); }
  res.sort((a, b) => a.s - b.s);
  let ini = 0;
  for (const x of nos) {
    while (ini < res.length && res[ini].e <= x.s) ini++;
    const ativos = [];
    for (let k = ini; k < res.length && res[k].s < x.e; k++) if (res[k].e > x.s) ativos.push(res[k]);
    if (!ativos.length) continue;
    const cortes = new Set([x.s, x.e]);
    ativos.forEach(r => { if (r.s > x.s) cortes.add(r.s); if (r.e < x.e) cortes.add(r.e); });
    const pts = [...cortes].sort((a, b) => a - b);
    const frag = document.createDocumentFragment();
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1];
      let nodo = document.createTextNode(x.n.nodeValue.slice(a - x.s, b - x.s));
      const cobre = ativos.filter(r => r.s <= a && r.e >= b).sort((p, q) => (p.h.em || 0) - (q.h.em || 0));
      for (const r of cobre) {
        const m = document.createElement('mark'); m.dataset.h = r.h.id; m.dataset.c = r.h.cor; if (r.h.nota) m.dataset.n = '1';
        m.appendChild(nodo); nodo = m;
      }
      frag.appendChild(nodo);
    }
    x.n.parentNode.replaceChild(frag, x.n);
  }
  return orfas;
}

function marcaDaSelecao(raiz, range) {
  if (!raiz.contains(range.commonAncestorContainer)) return null;
  let ini = offsetEm(raiz, range.startContainer, range.startOffset);
  let fim = offsetEm(raiz, range.endContainer, range.endOffset);
  if (ini < 0 || fim < 0 || fim <= ini) return null;
  const completo = raiz.textContent;
  while (ini < fim && /\s/.test(completo[ini])) ini++;
  while (fim > ini && /\s/.test(completo[fim - 1])) fim--;
  if (fim - ini < 2) return null;
  if (fim - ini > 6000) return { erro: 'Trecho longo demais. Marque até cerca de 6.000 caracteres por vez.' };
  return { ini, fim, txt: completo.slice(ini, fim), pre: completo.slice(Math.max(0, ini - 30), ini), suf: completo.slice(fim, fim + 30) };
}

/* ============ marcações do leitor: carregar, criar, editar, apagar ============ */
async function carregarMarcas(id) {
  const d = await privLer('marcas_' + id, { id, itens: [] });
  return Array.isArray(d.itens) ? d.itens : [];
}
function gravarMarcas(id, itens) { privGravar('marcas_' + id, { id, itens }); }

/* todas as marcações de todos os textos (tela "Marcações"); as chaves são as mesmas das rotas de leitura */
async function todasMarcas() {
  const pref = kPriv('marcas_'); const docs = [];
  LS.chaves(pref).forEach(k => { const d = LS.get(k, null); if (d && Array.isArray(d.itens) && d.itens.length) docs.push({ ...d, id: k.slice(pref.length) }); });
  return docs;
}
