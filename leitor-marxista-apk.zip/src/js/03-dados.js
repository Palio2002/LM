/* ============ dados: catálogo (GitHub), páginas ao vivo, rascunhos locais, dados privados ============
   • Catálogo: catalogo/catalogo.json no repositório público do dono. Qualquer pessoa lê; só quem tem o
     token do dono consegue gravar (o GitHub é quem recusa, não o app).
   • Páginas "ao vivo": o app baixa a página do marxists.org na hora e guarda uma cópia para ler sem internet.
   • Rascunhos: só no aparelho do dono. Marcações, favoritos e posição: só no aparelho de cada leitor. */

const CFG = window.LM_CONFIG || {};
const P = { dono: false, login: '', pronto: false };
const configOk = () => /^[\w.-]+\/[\w.-]+$/.test(CFG.repo || '');
const PASTA = () => String(CFG.pasta || 'catalogo').replace(/^\/+|\/+$/g, '');
const RAMO = () => CFG.branch || 'main';
const urlRaw = caminho => `https://raw.githubusercontent.com/${CFG.repo}/${RAMO()}/${caminho}`;
const urlApi = (caminho = '') => `https://api.github.com/repos/${CFG.repo}${caminho}`;
const CAMINHO_CAT = () => PASTA() + '/catalogo.json';

const Lib = { textos: new Map(), rasc: new Map(), vivo: false, lento: false, erroRede: '', desatualizado: false, atualizadoEm: 0 };
const ouvintes = new Set();
const avisarMudanca = () => ouvintes.forEach(f => { try { f(); } catch (e) { console.error(e); } });

/* ---------- GitHub (API de conteúdo) ---------- */
const Token = {
  ler: () => LS.get('token', ''),
  gravar: t => LS.set('token', t),
  apagar: () => { LS.del('token'); LS.del('dono'); },
};

function erroGh(r, o) {
  const j = Rede.json(r) || {}; const m = String(j.message || '');
  let txt;
  if (r.status === 401) txt = 'O GitHub recusou o token (inválido ou expirado). Crie outro e entre de novo no modo editor.';
  else if (r.status === 403 && /rate limit/i.test(m)) txt = 'O GitHub limitou o número de pedidos. Espere alguns minutos.';
  else if (r.status === 403) txt = 'O token não tem permissão de escrita neste repositório. Ele precisa de "Contents: Read and write".';
  else if (r.status === 404) txt = o === 'escrita' ? 'O repositório não foi encontrado ou o token não tem acesso a ele.' : 'Não encontrei o repositório ' + CFG.repo + '. Confira se ele é público e se o nome está certo.';
  else if (r.status === 409 || r.status === 422) txt = 'Conflito ao gravar: o catálogo mudou enquanto você editava.';
  else txt = 'O GitHub respondeu com erro ' + r.status + (m ? ' (' + m.slice(0, 120) + ')' : '') + '.';
  return Object.assign(new Error(txt), { status: r.status, conflito: r.status === 409 || r.status === 422 });
}

async function gh(metodo, caminho, dados) {
  const tok = Token.ler(); if (!tok) throw new Error('Entre no modo editor (em Ajustes) para fazer isso.');
  const cab = { Authorization: 'Bearer ' + tok, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' };
  if (dados !== undefined) cab['Content-Type'] = 'application/json';
  return Rede.pedir({ url: urlApi(caminho), metodo, cabecalhos: cab, dados });
}

async function ghLerArquivo(caminho) {
  const r = await gh('GET', `/contents/${caminho}?ref=${encodeURIComponent(RAMO())}`);
  if (r.status === 404) return { sha: null, texto: null, json: null };
  if (r.status !== 200) throw erroGh(r, 'leitura');
  const j = Rede.json(r) || {};
  let texto = null;
  if (j.encoding === 'base64' && j.content) texto = textoDeBase64(j.content);
  else if (j.sha) { /* arquivos grandes não vêm no corpo: busca o blob */
    const b = await gh('GET', `/git/blobs/${j.sha}`); if (b.status !== 200) throw erroGh(b, 'leitura');
    texto = textoDeBase64((Rede.json(b) || {}).content || '');
  }
  let json = null; try { json = texto == null ? null : JSON.parse(texto); } catch (e) { json = null; }
  return { sha: j.sha || null, texto, json };
}

async function ghGravarArquivo(caminho, texto, mensagem, sha) {
  const corpo = { message: mensagem, content: base64DeTexto(texto), branch: RAMO() };
  if (sha) corpo.sha = sha;
  const r = await gh('PUT', `/contents/${caminho}`, corpo);
  if (r.status === 200 || r.status === 201) return Rede.json(r);
  throw erroGh(r, 'escrita');
}

async function ghApagarArquivo(caminho, mensagem) {
  const atual = await ghLerArquivo(caminho); if (!atual.sha) return;
  const r = await gh('DELETE', `/contents/${caminho}`, { message: mensagem, sha: atual.sha, branch: RAMO() });
  if (r.status !== 200 && r.status !== 404) throw erroGh(r, 'escrita');
}

/* lê o catálogo mais recente, aplica fn e grava; se alguém mudou no meio, tenta de novo */
async function catalogoEditar(fn, mensagem) {
  let ultimo;
  for (let t = 0; t < 3; t++) {
    const atual = await ghLerArquivo(CAMINHO_CAT());
    const cat = atual.json && Array.isArray(atual.json.itens) ? atual.json : { versao: 1, itens: [] };
    fn(cat); cat.versao = 1; cat.atualizadoEm = agora();
    try {
      await ghGravarArquivo(CAMINHO_CAT(), JSON.stringify(cat, null, 1) + '\n', mensagem, atual.sha);
      aplicarCatalogo(cat, true); return cat;
    } catch (e) { ultimo = e; if (!e.conflito) throw e; await esperar(400); }
  }
  throw ultimo;
}

/* ---------- catálogo ---------- */
function aplicarCatalogo(cat, vivo) {
  const itens = (cat && Array.isArray(cat.itens) ? cat.itens : []).filter(t => t && typeof t.id === 'string' && /^[\w]{3,40}$/.test(t.id) && t.titulo);
  Lib.textos = new Map(itens.map(t => [t.id, t]));
  Lib.vivo = !!vivo; Lib.lento = false; Lib.erroRede = ''; Lib.desatualizado = !vivo; Lib.atualizadoEm = (cat && cat.atualizadoEm) || 0;
  if (vivo) IDB.set('catalogo', { versao: 1, atualizadoEm: Lib.atualizadoEm, itens });
  avisarMudanca();
}

async function carregarCatalogo() {
  if (!Lib.textos.size) {
    const cache = await IDB.get('catalogo');
    if (cache && Array.isArray(cache.itens) && cache.itens.length) { aplicarCatalogo(cache, false); }
  }
  if (!configOk()) { Lib.lento = true; Lib.erroRede = 'config'; avisarMudanca(); return; }
  let ultimaFalha = null;
  const tentativas = [];
  if (Token.ler() && P.dono) tentativas.push(async () => { const a = await ghLerArquivo(CAMINHO_CAT()); return a.json || { itens: [] }; });
  tentativas.push(async () => {
    const r = await Rede.pedir({ url: urlRaw(CAMINHO_CAT()) + '?v=' + Math.floor(agora() / 60000) });
    if (r.status === 404) return { itens: [] };
    if (r.status !== 200) throw new Error('O GitHub respondeu com erro ' + r.status + '.');
    const j = Rede.json(r); if (!j || !Array.isArray(j.itens)) throw new Error('O catálogo está com formato inválido.');
    return j;
  });
  for (const t of tentativas) {
    try { aplicarCatalogo(await t(), true); return; } catch (e) { ultimaFalha = e; }
  }
  Lib.lento = true; Lib.erroRede = (ultimaFalha && ultimaFalha.message) || 'erro'; avisarMudanca();
}

/* ---------- modo editor (token do dono) ---------- */
async function entrarModoEditor(tok) {
  tok = String(tok || '').trim();
  if (!configOk()) throw new Error('O app ainda não sabe qual é o seu repositório (arquivo config.js). Veja o README.');
  if (!/^[\w-]{20,255}$/.test(tok)) throw new Error('Esse token não parece válido. Cole o token inteiro, sem espaços.');
  Token.gravar(tok);
  let r; try { r = await gh('GET', ''); } catch (e) { Token.apagar(); throw e; }
  if (r.status !== 200) { Token.apagar(); throw erroGh(r, 'leitura'); }
  const j = Rede.json(r) || {};
  if (j.permissions && j.permissions.push === false) { Token.apagar(); throw new Error('Esse token só consegue ler o repositório. Crie um com permissão "Contents: Read and write".'); }
  P.dono = true; P.login = (j.owner && j.owner.login) || '';
  LS.set('dono', { login: P.login, repo: CFG.repo, em: agora() });
  atualizarChrome(); carregarCatalogo();
}
function sairDoModoEditor() {
  Token.apagar(); P.dono = false; P.login = ''; atualizarChrome();
  if (/^#(admin|rascunho)/.test(location.hash)) irPara('inicio'); else if (E.refresh) E.refresh();
}
async function revalidarEditor() {
  if (!Token.ler()) { P.dono = false; return; }
  const d = LS.get('dono', null);
  P.dono = !!(d && d.repo === CFG.repo); P.login = (d && d.login) || ''; atualizarChrome();
  if (!P.dono || !configOk()) return;
  try {
    const r = await gh('GET', '');
    const j = r.status === 200 ? (Rede.json(r) || {}) : null;
    if (r.status === 401 || (j && j.permissions && j.permissions.push === false)) { sairDoModoEditor(); aviso('O token do modo editor deixou de valer. Entre de novo em Ajustes.', 5000); }
  } catch (e) { /* sem internet: mantém o modo editor */ }
}

/* ---------- textos do catálogo e páginas ao vivo ---------- */
const memCorpo = new Map();
async function corpoArquivo(t) {
  const chave = `corpo:${t.id}:${t.versao || 0}`;
  if (memCorpo.has(chave)) return memCorpo.get(chave);
  let html = await IDB.get(chave);
  if (html == null) {
    const r = await Rede.pedir({ url: urlRaw(`${PASTA()}/textos/${t.id}.json`) + '?v=' + (t.versao || 0) });
    if (r.status === 404) throw new Error('O arquivo deste texto não está no repositório (foi apagado?).');
    if (r.status !== 200) throw new Error('O GitHub respondeu com erro ' + r.status + '.');
    const j = Rede.json(r); if (!j || typeof j.html !== 'string') throw new Error('O arquivo do texto está com formato inválido.');
    html = j.html; IDB.set(chave, html);
  }
  memCorpo.set(chave, html);
  return html;
}

const memPag = new Map();
/* devolve a página limpa; usa a cópia guardada, a menos que se peça para atualizar */
async function lerPagina(url, { forcar = false } = {}) {
  url = semFragmento(url);
  const chave = 'pg:' + url;
  let guardada = memPag.get(chave) || await IDB.get(chave);
  if (guardada && !forcar) { memPag.set(chave, guardada); return { ...guardada, deCache: true }; }
  try {
    const b = await baixarPagina(url);
    const r = importarPagina(b.texto, b.url, b.ehTxt);
    const dados = { url, html: r.html, meta: { titulo: r.titulo, autor: r.autor, ano: r.ano, credito: r.credito }, em: agora(), avisos: r.avisos || [], candidatos: r.candidatos || [], indice: !!r.indice, cod: b.cod };
    if (tamTexto(r.html) >= TEXTO_MINIMO) { IDB.set(chave, dados); memPag.set(chave, dados); if (memPag.size > 8) memPag.delete(memPag.keys().next().value); }
    return { ...dados, deCache: false };
  } catch (e) {
    if (guardada) return { ...guardada, deCache: true, offline: true };
    throw e;
  }
}

/* ---------- escrita no catálogo (só o dono: o GitHub recusa qualquer outra pessoa) ---------- */
function metaDe(d) {
  return {
    titulo: d.titulo.trim(), autor: d.autor.trim(), ano: String(d.ano || '').trim(), temas: d.temas || [],
    fonte: (d.fonte || '').trim(), credito: (d.credito || '').trim(),
  };
}

async function publicarRascunho(d, aoProgresso = () => { }) {
  const bloqueio = bloqueioDeTexto(d.html); if (bloqueio) throw new Error(bloqueio);
  if (!P.dono) throw new Error('Entre no modo editor (em Ajustes) para publicar.');
  const tipo = d.tipo === 'ao-vivo' ? 'ao-vivo' : 'arquivo';
  const versao = agora();
  const txt = textoPuro(d.html).replace(/\s+/g, ' ').trim();
  const antigo = Lib.textos.get(d.id);
  const item = { id: d.id, ...metaDe(d), tipo, chars: txt.length, trecho: txt.slice(0, 180), versao, publicadoEm: (antigo && antigo.publicadoEm) || agora(), atualizadoEm: agora() };
  if (tipo === 'ao-vivo') {
    const u = normalizarUrlMia(d.url); if (!u) throw new Error('O endereço do texto precisa ser do marxists.org.');
    item.url = u; if (!item.fonte) item.fonte = u;
    if (d.temCapitulos && (d.capitulos || []).length) item.capitulos = d.capitulos.map(c => ({ t: String(c.t).slice(0, 200), u: normalizarUrlMia(c.u) })).filter(c => c.u);
  } else {
    const corpo = JSON.stringify({ id: d.id, versao, html: d.html });
    if (corpo.length > 7000000) throw new Error('Texto grande demais para publicar (limite de cerca de 7 MB).');
    aoProgresso(1, 2);
    const caminho = `${PASTA()}/textos/${d.id}.json`;
    const atual = await ghLerArquivo(caminho);
    await ghGravarArquivo(caminho, corpo, 'Texto: ' + d.titulo.slice(0, 80), atual.sha);
  }
  aoProgresso(2, 2);
  await catalogoEditar(cat => { const i = cat.itens.findIndex(x => x.id === d.id); if (i >= 0) cat.itens[i] = item; else cat.itens.unshift(item); }, 'Publicar: ' + d.titulo.slice(0, 80));
  memCorpo.delete(`corpo:${d.id}:${(antigo && antigo.versao) || 0}`);
  await apagarRascunho(d.id);
}

async function excluirPublicado(t) {
  await catalogoEditar(cat => { cat.itens = cat.itens.filter(x => x.id !== t.id); }, 'Remover: ' + t.titulo.slice(0, 80));
  if (t.tipo !== 'ao-vivo') { try { await ghApagarArquivo(`${PASTA()}/textos/${t.id}.json`, 'Remover arquivo: ' + t.titulo.slice(0, 80)); } catch (e) { /* o catálogo já não aponta para ele */ } }
  memCorpo.delete(`corpo:${t.id}:${t.versao || 0}`); IDB.del(`corpo:${t.id}:${t.versao || 0}`);
}

async function despublicar(t) {
  let html = '';
  if (t.tipo === 'ao-vivo') { const g = await IDB.get('pg:' + semFragmento(t.url || '')); html = g ? g.html : ''; }
  else html = await corpoArquivo(t);
  await gravarRascunho({
    id: t.id, titulo: t.titulo, autor: t.autor, ano: t.ano, temas: t.temas || [], fonte: t.fonte, credito: t.credito, html, chars: t.chars,
    tipo: t.tipo === 'ao-vivo' ? 'ao-vivo' : 'arquivo', url: t.url || '', temCapitulos: !!(t.capitulos && t.capitulos.length), capitulos: t.capitulos || [], candidatos: t.capitulos || [],
    arquivo: '', avisos: [], conferido: { a: false, b: false, c: false }, publicadoEm: t.publicadoEm, criadoEm: agora(),
  });
  await excluirPublicado(t);
}

async function salvarMetaPublicado(t, campos) {
  const m = metaDe({ ...t, ...campos });
  await catalogoEditar(cat => { const x = cat.itens.find(i => i.id === t.id); if (x) Object.assign(x, m, { atualizadoEm: agora() }); }, 'Editar dados: ' + m.titulo.slice(0, 80));
}

/* ---------- rascunhos (guardados só neste aparelho) ---------- */
async function carregarRascunhos() {
  const arr = await IDB.get('rascunhos');
  Lib.rasc = new Map((Array.isArray(arr) ? arr : []).map(d => [d.id, d]));
  avisarMudanca();
}
const guardarListaRasc = () => IDB.set('rascunhos', [...Lib.rasc.values()]);

async function gravarRascunho(d, { corpo = true } = {}) {
  const base = Lib.rasc.get(d.id) || {};
  const meta = {
    ...metaDe({ ...d, titulo: d.titulo || '', autor: d.autor || '' }), id: d.id,
    tipo: d.tipo === 'ao-vivo' ? 'ao-vivo' : 'arquivo', url: d.url || '', temCapitulos: !!d.temCapitulos, capitulos: d.capitulos || [], candidatos: d.candidatos || [],
    chars: d.chars || 0, arquivo: d.arquivo || '', cod: d.cod || '', avisos: d.avisos || [], conferido: d.conferido || { a: false, b: false, c: false },
    criadoEm: d.criadoEm || base.criadoEm || agora(), atualizadoEm: agora(), publicadoEm: d.publicadoEm || 0,
  };
  if (corpo && (await IDB.set('rcorpo:' + d.id, d.html || '')) === undefined) throw new Error('Não consegui guardar o rascunho neste aparelho (falta espaço?).');
  Lib.rasc.set(d.id, meta);
  if ((await guardarListaRasc()) === undefined) throw new Error('Não consegui guardar o rascunho neste aparelho (falta espaço?).');
  avisarMudanca();
}
async function carregarRascunho(id) {
  const m = Lib.rasc.get(id); if (!m) return null;
  const html = await IDB.get('rcorpo:' + id);
  return { ...m, html: typeof html === 'string' ? html : '' };
}
async function apagarRascunho(id) {
  Lib.rasc.delete(id); await IDB.del('rcorpo:' + id); await guardarListaRasc(); avisarMudanca();
}

/* ---------- dados privados de quem lê: preferências, favoritos, posição, marcações (só neste aparelho) ---------- */
const kPriv = nome => 'p.' + nome;
async function privLer(nome, padrao) { return LS.get(kPriv(nome), padrao); }
function privGravar(nome, dado) {
  dado.em = agora();
  if (!LS.set(kPriv(nome), dado)) aviso('Não consegui guardar neste aparelho (armazenamento cheio?).', 4000);
}
function privDescarregar() { /* tudo já é gravado na hora */ }

const PADRAO_PREFS = { fonte: 'literata', tam: 19, lh: 1.6, margem: 18, alinhar: 'left', tema: 'auto', hifen: false };
const E = {
  rota: { nome: 'inicio', arg: '' },
  prefs: { ...PADRAO_PREFS },
  estado: { fav: [], pos: {}, rec: [], docs: {} },
  filtro: { q: '', autor: '', tema: '', ordem: 'recentes' },
  leitor: null, refresh: null,
};

/* ---------- qual é o "documento" de uma rota ----------
   #ler-<id>        texto do catálogo (uma página, ou arquivo guardado no repositório)
   #ler-<id>.<n>    capítulo n (1, 2, …) de uma obra do catálogo
   #ler-u.<url>     qualquer página do marxists.org (a URL vai codificada) */
function analisarChave(chave) {
  if (chave.startsWith('u.')) { let url = ''; try { url = decodeURIComponent(chave.slice(2)); } catch (e) { url = ''; } return { tipo: 'url', url: normalizarUrlMia(url) }; }
  const m = chave.match(/^(\w{3,40})(?:\.(\d{1,3}))?$/);
  return m ? { tipo: 'cat', id: m[1], cap: m[2] ? +m[2] : 0 } : { tipo: 'invalida' };
}
/* se a página já faz parte de uma obra do catálogo, a chave dela é a do catálogo (as marcações ficam juntas) */
function chaveParaUrl(url) {
  const alvo = semFragmento(url);
  for (const t of Lib.textos.values()) {
    if (t.url && semFragmento(t.url) === alvo && !(t.capitulos && t.capitulos.length)) return t.id;
    const i = (t.capitulos || []).findIndex(c => semFragmento(c.u) === alvo);
    if (i >= 0) return t.id + '.' + (i + 1);
  }
  return chaveDeUrl(alvo);
}
function infoDoc(chave) {
  if (chave.startsWith('u.')) {
    const d = (E.estado.docs || {})[chave];
    let u = ''; try { u = decodeURIComponent(chave.slice(2)); } catch (e) { /* ignora */ }
    return { titulo: (d && d.titulo) || u || 'Página do marxists.org', autor: (d && d.autor) || '', ano: (d && d.ano) || '', url: u };
  }
  const [id, n] = chave.split('.'); const t = Lib.textos.get(id);
  if (!t) { const d = (E.estado.docs || {})[chave]; return d ? { titulo: d.titulo, autor: d.autor || '', ano: d.ano || '' } : null; }
  if (n && t.capitulos && t.capitulos[n - 1]) return { titulo: t.capitulos[n - 1].t, sub: t.titulo, autor: t.autor, ano: t.ano, url: t.capitulos[n - 1].u };
  return { titulo: t.titulo, autor: t.autor, ano: t.ano, url: t.url || t.fonte || '' };
}
function lembrarDoc(chave, info) {
  const docs = E.estado.docs = E.estado.docs || {};
  delete docs[chave]; docs[chave] = { titulo: info.titulo, autor: info.autor || '', ano: info.ano || '' };
  const ks = Object.keys(docs); if (ks.length > 250) delete docs[ks[0]];
}
