/* ============ importação: arquivo → HTML limpo ============ */
const PERMITIDAS = new Set('p br hr h1 h2 h3 h4 h5 h6 blockquote ul ol li dl dt dd table thead tbody tfoot tr td th caption em i strong b u s sup sub small span div a pre code cite q abbr figure figcaption'.split(' '));
const DESCARTAR = new Set('script style link meta iframe frame frameset input button select textarea noscript object embed svg canvas audio video map applet title head base template'.split(' '));
/* blocos de navegação do site: só saem se forem curtos e feitos de links; se tiverem texto de verdade, ficam (form/header/footer/nav nunca levam o texto junto) */
const SUAVES = new Set(['header', 'footer', 'nav', 'aside']);
function navegacional(n) {
  const todo = (n.textContent || '').replace(/\s+/g, ' ').trim().length;
  const links = [...n.querySelectorAll('a')].reduce((t, a) => t + (a.textContent || '').replace(/\s+/g, ' ').trim().length, 0);
  return todo - links < 60;
}
const INLINE = new Set('em i strong b u s sup sub small span a code cite q abbr br'.split(' '));
const LIXO_CLASSE = /toplink|noprint|navbar|menu-?topo|rodape/i;
const LIXO_LINK = /^(inicio da pagina|topo|voltar|voltar ao (topo|indice|inicio)|seja um voluntario!?|indice|ir para o topo)$/;

function atributos(src, dst, tag, base) {
  const id = src.getAttribute('id') || (tag === 'a' ? src.getAttribute('name') : '');
  if (id && /^[\w:.\-]{1,80}$/.test(id)) dst.setAttribute('id', id);
  for (const a of ['colspan', 'rowspan']) { const v = src.getAttribute(a); if (v && /^\d{1,2}$/.test(v)) dst.setAttribute(a, v); }
  const ti = src.getAttribute('title'); if (ti && tag !== 'a') dst.setAttribute('title', ti.slice(0, 200));
  if (tag === 'a') {
    const href = (src.getAttribute('href') || '').trim();
    if (href.startsWith('#')) { dst.setAttribute('href', href); }
    else if (href) {
      let u = null;
      try { u = new URL(href, base || undefined); } catch (e) { u = null; }
      if (u && /^https?:$/.test(u.protocol)) { dst.setAttribute('href', u.href); dst.setAttribute('target', '_blank'); dst.setAttribute('rel', 'noopener noreferrer'); }
    }
  }
}

/* imagem de uma página do marxists.org: só https e só do próprio site */
function imagemMia(src, base) {
  if (!base || !src) return '';
  try { const u = new URL(src, base); if (/^https?:$/.test(u.protocol) && MIA_RE.test(u.hostname) && MIA_RE.test(new URL(base).hostname)) { u.protocol = 'https:'; return u.href; } } catch (e) { /* ignora */ }
  return '';
}

function copiarNos(src, dst, base, cons) {
  for (const n of [...src.childNodes]) {
    if (n.nodeType === 3) { dst.appendChild(document.createTextNode(n.nodeValue)); continue; }
    if (n.nodeType !== 1) continue;
    const tag = n.tagName.toLowerCase();
    if (DESCARTAR.has(tag)) continue;
    if (!cons && SUAVES.has(tag) && navegacional(n)) continue;
    if (!cons && LIXO_CLASSE.test(n.getAttribute('class') || '')) continue;
    if (tag === 'img') {
      const s = n.getAttribute('src') || ''; const alt = (n.getAttribute('alt') || '').trim();
      const viva = imagemMia(s, base);
      if (/^data:image\/(png|jpe?g|gif|webp);base64,/i.test(s) && s.length < 400000) {
        const im = document.createElement('img'); im.setAttribute('src', s); if (alt) im.setAttribute('alt', alt.slice(0, 200)); dst.appendChild(im);
      } else if (viva) {
        const im = document.createElement('img'); im.setAttribute('src', viva); im.setAttribute('loading', 'lazy'); im.setAttribute('alt', alt.slice(0, 200)); dst.appendChild(im);
      } else if (alt) { const sp = document.createElement('span'); sp.className = 'img-ausente'; sp.textContent = '[imagem: ' + alt.slice(0, 120) + ']'; dst.appendChild(sp); }
      continue;
    }
    if (!PERMITIDAS.has(tag)) { copiarNos(n, dst, base, cons); continue; } /* tags desconhecidas: mantém só o conteúdo */
    const el = document.createElement(tag);
    atributos(n, el, tag, base);
    copiarNos(n, el, base, cons);
    dst.appendChild(el);
  }
}

/* texto solto no topo (ou separado por <br><br>) vira parágrafo */
function empacotarSolto(raiz) {
  const saida = document.createElement('div');
  let buf = [];
  const despejar = () => {
    const comTexto = buf.some(n => (n.nodeType === 3 && n.nodeValue.trim()) || (n.nodeType === 1 && n.textContent.trim()));
    if (!comTexto) { buf.forEach(n => { if (n.nodeType === 1 && n.id) saida.appendChild(n); }); buf = []; return; }
    let p = document.createElement('p'); let seguidos = 0;
    for (const n of buf) {
      if (n.nodeType === 1 && n.tagName === 'BR') {
        seguidos++;
        if (seguidos >= 2) { if (p.textContent.trim() || p.querySelector('[id]')) saida.appendChild(p); p = document.createElement('p'); }
        else p.appendChild(n);
        continue;
      }
      if (n.nodeType === 3 && !n.nodeValue.trim() && seguidos) continue;
      seguidos = 0; p.appendChild(n);
    }
    if (p.textContent.trim() || p.querySelector('[id]')) saida.appendChild(p);
    buf = [];
  };
  for (const n of [...raiz.childNodes]) {
    const inline = n.nodeType === 3 || (n.nodeType === 1 && INLINE.has(n.tagName.toLowerCase()));
    if (inline) buf.push(n); else { despejar(); saida.appendChild(n); }
  }
  despejar();
  return saida;
}

function limparHtml(corpo, base, cons) {
  const tmp = document.createElement('div');
  copiarNos(corpo, tmp, base, cons);
  /* links de navegação do site ("Início da página", "Voltar") */
  $$('a', tmp).forEach(a => {
    const t = fold(a.textContent.trim());
    if (!LIXO_LINK.test(t)) return;
    if (t === 'voltar' && (a.getAttribute('href') || '').startsWith('#')) return; /* volta de nota de rodapé: manter */
    const p = a.closest('p');
    const soLink = p && p.textContent.trim() === a.textContent.trim() && !p.querySelector('[id]');
    (soLink ? p : a).remove();
  });
  const raiz = empacotarSolto(tmp);
  /* tira elementos vazios */
  $$('p,div,span,li,blockquote', raiz).reverse().forEach(e => {
    if (!e.textContent.trim() && !e.querySelector('img,hr,table,[id]') && !e.id) e.remove();
  });
  return raiz.innerHTML.replace(/\n{3,}/g, '\n\n').trim();
}

function textoPuro(html) { const d = document.createElement('div'); d.innerHTML = html; return d.textContent || ''; }

function limparTitulo(t) { return String(t || '').replace(/\s+/g, ' ').replace(/\(\d+\*?\)/g, '').trim(); }

const RE_CRED = /^(fonte|tradu[cç][aã]o|transcri[cç][aã]o|revis[aã]o|publicad[oa]|primeira edi[cç][aã]o|edi[cç][aã]o|direitos|html|data de publica[cç][aã]o|copyleft)\b[^:：]{0,30}[:：]/i;

/* linhas de um bloco, separando onde havia <br> */
function linhasDe(e) {
  const c = e.cloneNode(true);
  c.querySelectorAll('br').forEach(b => b.replaceWith('\u0001'));
  return c.textContent.split('\u0001').map(s => s.replace(/\s+/g, ' ').trim()).filter(Boolean);
}

/* lê título, autor, crédito e ano; tira do corpo o título repetido e o bloco de crédito (já vão para os campos) */
function prepararDoc(doc, nomeArq) {
  const meta = { titulo: '', autor: '', ano: '', credito: '' };
  const h1 = doc.querySelector('h1');
  meta.titulo = limparTitulo((h1 && h1.textContent) || doc.title || '') || nomeArq.replace(/\.[a-z0-9]+$/i, '');
  const ma = doc.querySelector('meta[name="author" i]');
  if (ma && ma.getAttribute('content')) meta.autor = ma.getAttribute('content').trim();
  const cands = $$('p,h2,h3,h4,li,div', doc.body).filter(e => e.tagName !== 'DIV' || !e.querySelector('p,div')).slice(0, 60);
  const cred = []; const remover = [];
  for (const e of cands) {
    const ls = linhasDe(e); if (!ls.length || ls.join(' ').length > 420) continue;
    if (!meta.autor) for (const l of ls) { const m = l.match(/^(?:autor(?:a)?|por)\s*[:：]\s*(.{3,80})$/i); if (m) { meta.autor = m[1].trim(); break; } }
    const casam = ls.filter(l => RE_CRED.test(l));
    if (!casam.length) continue;
    casam.forEach(l => { if (!cred.includes(l)) cred.push(l); });
    if (casam.length === ls.length && remover.length < 6) remover.push(e);
  }
  meta.credito = cred.slice(0, 6).join(' · ');
  const linhasAno = cred.filter(l => /^(data|escrit|primeira|publicad)/i.test(l)).join(' ');
  const mAno = (linhasAno + ' ' + meta.titulo).match(/\b(1[5-9]\d\d|20[0-2]\d)\b/);
  if (mAno) meta.ano = mAno[1];
  remover.forEach(e => e.remove());
  if (h1 && h1.isConnected && fold(limparTitulo(h1.textContent)) === fold(meta.titulo)) h1.remove();
  return meta;
}

const tamTexto = h => textoPuro(h).replace(/\s+/g, ' ').trim().length;
const AVISO_INDICE = 'Esta página parece ser um índice (uma lista de links), com pouco texto próprio. Para obras de vários capítulos, importe cada capítulo; se existir uma versão da obra inteira em uma página só, use essa.';
const TEXTO_MINIMO = 80; /* abaixo disso o texto não pode ser publicado */

function textoBruto(corpo) {
  const c = corpo.cloneNode(true);
  c.querySelectorAll('script,style,noscript,template,head,title').forEach(e => e.remove());
  return (c.textContent || '').replace(/\s+/g, ' ').trim();
}
/* última rede: todo o texto visível da página, em parágrafos */
function textoEmBlocos(corpo) {
  const c = corpo.cloneNode(true);
  c.querySelectorAll('script,style,noscript,template,head,title,iframe,object,embed,svg,input,button,select,textarea').forEach(e => e.remove());
  c.querySelectorAll('br').forEach(b => b.replaceWith('\n'));
  c.querySelectorAll('p,div,h1,h2,h3,h4,h5,h6,li,tr,blockquote,pre,dt,dd,table,ul,ol,hr,form').forEach(e => e.append('\n\n'));
  return (c.textContent || '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
}

/* limpa o corpo da página sem nunca deixá-lo vazio quando havia texto */
function extrairCorpo(doc, base) {
  const bruto = textoBruto(doc.body).length;
  let html = limparHtml(doc.body, base, false); let modo = 'normal';
  const perdeu = h => { const n = tamTexto(h); return n < 0.35 * bruto && bruto - n > 300; };
  if (perdeu(html)) {
    const h2 = limparHtml(doc.body, base, true);
    if (tamTexto(h2) > tamTexto(html)) { html = h2; modo = 'conservador'; }
  }
  if (perdeu(html)) {
    const h3 = textoParaHtml(textoEmBlocos(doc.body));
    if (tamTexto(h3) > tamTexto(html)) { html = h3; modo = 'texto'; }
  }
  const avisos = []; let indice = false;
  if (modo !== 'normal') avisos.push(`A limpeza automática tirava quase todo o texto da página (de ${bruto.toLocaleString('pt-BR')} caracteres sobravam poucos), então usei uma extração mais simples. Confira com atenção se sobraram menus ou rodapés do site no começo e no fim.`);
  if (doc.querySelector('frameset, frame')) avisos.push('Esta página usa quadros (frames): o texto costuma ficar em outro arquivo. Abra a página do texto em si e salve ela, em vez da página que monta os quadros.');
  const as = [...doc.body.querySelectorAll('a[href]')].filter(a => !(a.getAttribute('href') || '').startsWith('#'));
  const nl = as.reduce((t, a) => t + (a.textContent || '').replace(/\s+/g, ' ').trim().length, 0);
  if (as.length >= 5 && bruto && nl / bruto > 0.5 && tamTexto(html) < 6000) indice = true;
  return { html, bruto, modo, avisos, indice };
}

function avisosDe(html, chars, opc = {}) {
  const av = [];
  if (/Ã[£©§¡³ªµ‰]|â€|\uFFFD/.test(html)) av.push('Aparecem caracteres estranhos (como "Ã©" ou "\uFFFD"). A codificação do arquivo pode ter sido lida errada; confira a pré-visualização.');
  if (chars < TEXTO_MINIMO) av.push('O texto está vazio ou quase vazio, então não dá para publicar. Veja se o arquivo certo foi enviado.');
  else if (chars < 300 && !opc.temCapitulos) av.push('O texto ficou muito curto. Veja se o arquivo certo foi enviado.');
  if (html.length > 3000000) av.push('Texto muito grande (mais de 3 MB). Funciona, mas abre devagar no celular.');
  return av;
}

/* mensagem se o texto não pode ser publicado; '' se pode */
function bloqueioDeTexto(html) {
  const n = tamTexto(html || '');
  return n < TEXTO_MINIMO ? `O texto está vazio ou curto demais (${n} caracteres) para ser publicado. Importe de novo ou cole o texto em “Corrigir o texto”.` : '';
}

function montarRascunho(base) {
  const chars = tamTexto(base.html);
  return {
    id: novoId(), titulo: '', autor: '', ano: '', temas: [], fonte: '', credito: '', arquivo: '',
    conferido: { a: false, b: false, c: false }, criadoEm: agora(), ...base,
    chars, avisos: [...(base.avisos || []), ...avisosDe(base.html, chars, base)],
  };
}

function importarHtml(raw, nome) {
  const m = raw.slice(0, 4000).match(/saved from url=\(\d+\)\s*(\S+)/i);
  let fonte = m ? m[1] : '';
  const doc = new DOMParser().parseFromString(raw, 'text/html');
  if (!fonte) {
    const c = doc.querySelector('link[rel="canonical" i]'); const og = doc.querySelector('meta[property="og:url" i]');
    const cand = (c && c.getAttribute('href')) || (og && og.getAttribute('content')) || '';
    if (/^https?:\/\//i.test(cand)) fonte = cand;
  }
  const be = doc.querySelector('base[href]');
  const baseUrl = fonte || (be && /^https?:\/\//i.test(be.getAttribute('href')) ? be.getAttribute('href') : '');
  const meta = prepararDoc(doc, nome);
  const ex = extrairCorpo(doc, baseUrl);
  return montarRascunho({ ...meta, fonte, html: ex.html, arquivo: nome, avisos: ex.avisos.concat(ex.indice ? [AVISO_INDICE] : []) });
}

/* texto simples ou markdown → HTML */
function inlineMd(s) {
  let t = esc(s);
  t = t.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  t = t.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>').replace(/(^|[\s(])\*([^*\n]+)\*(?=[\s).,;:!?]|$)/g, '$1<em>$2</em>').replace(/(^|[\s(])_([^_\n]+)_(?=[\s).,;:!?]|$)/g, '$1<em>$2</em>');
  return t;
}

function textoParaHtml(txt, { md = false, juntar = true } = {}) {
  const linhas = txt.replace(/\r\n?/g, '\n').replace(/ /g, ' ').split('\n');
  const blocos = []; let at = [];
  for (const l of linhas) { if (!l.trim()) { if (at.length) { blocos.push(at); at = []; } } else at.push(l); }
  if (at.length) blocos.push(at);
  const inl = s => md ? inlineMd(s) : esc(s);
  const out = [];
  for (const b of blocos) {
    const prim = b[0].trim(); let m;
    if (md && (m = prim.match(/^(#{1,6})\s+(.+?)\s*#*$/))) {
      out.push(`<h${m[1].length}>${inl(m[2])}</h${m[1].length}>`);
      if (b.length > 1) out.push(`<p>${b.slice(1).map(x => inl(x.trim())).join(juntar ? ' ' : '<br>')}</p>`);
    } else if (/^(-{3,}|\*{3,}|_{3,})$/.test(prim) && b.length === 1) out.push('<hr>');
    else if (md && b.every(l => /^\s*>/.test(l))) out.push(`<blockquote><p>${b.map(l => inl(l.replace(/^\s*>\s?/, '').trim())).join(' ')}</p></blockquote>`);
    else if (b.length >= 1 && b.every(l => /^\s*([-*•]|\d+[.)])\s+/.test(l)) && (md || b.length > 1)) {
      const ord = /^\s*\d+[.)]/.test(b[0]); const tag = ord ? 'ol' : 'ul';
      out.push(`<${tag}>${b.map(l => `<li>${inl(l.replace(/^\s*([-*•]|\d+[.)])\s+/, ''))}</li>`).join('')}</${tag}>`);
    } else if (b.length === 1 && prim.length >= 3 && prim.length <= 90 && !/[.,;:]$/.test(prim) &&
      ((prim === prim.toUpperCase() && /[A-ZÁÉÍÓÚÂÊÔÃÕÇ]{3}/.test(prim)) || /^(cap[ií]tulo|parte|livro|se[cç][aã]o|pref[aá]cio|introdu[cç][aã]o|[IVXLC]+[.)]\s)/i.test(prim))) {
      out.push(`<h3>${inl(prim)}</h3>`);
    } else out.push(`<p>${b.map(x => inl(x.trim())).join(juntar ? ' ' : '<br>')}</p>`);
  }
  return out.join('\n');
}

function importarTexto(txtOriginal, nome, { md = false, juntar = true } = {}) {
  /* linhas "Título:", "Autor:", "Fonte:"... no começo do arquivo viram campos e saem do corpo */
  const linhas = txtOriginal.replace(/\r\n?/g, '\n').split('\n');
  const re = /^\s*(t[ií]tulo|autor(?:a)?|por|fonte|tradu[cç][aã]o|transcri[cç][aã]o|data|ano)\s*[:：]\s*(.+?)\s*$/i;
  let i = 0; while (i < linhas.length && !linhas[i].trim()) i++;
  let j = i; const ach = [];
  while (j < linhas.length) {
    const m = linhas[j].match(re);
    if (m) { ach.push([fold(m[1]), m[2]]); j++; }
    else if (!linhas[j].trim() && ach.length && j + 1 < linhas.length && re.test(linhas[j + 1])) j++;
    else break;
  }
  const txt = ach.length ? linhas.slice(j).join('\n') : txtOriginal;
  const pega = (...ks) => { const x = ach.find(a => ks.includes(a[0])); return x ? x[1] : ''; };
  const html = textoParaHtml(txt, { md, juntar });
  let titulo = pega('titulo');
  if (!titulo) {
    const mh = md && txt.match(/^\s*#\s+(.+)$/m);
    if (mh) titulo = mh[1].trim();
    else { const prim = txt.split('\n').map(s => s.trim()).find(Boolean) || ''; if (prim && prim.length <= 110) titulo = prim; }
  }
  if (!titulo) titulo = nome.replace(/\.[a-z0-9]+$/i, '');
  const fonteBruta = pega('fonte');
  const credito = [fonteBruta && !/^https?:\/\//i.test(fonteBruta) ? 'Fonte: ' + fonteBruta : '', pega('traducao') ? 'Tradução: ' + pega('traducao') : '', pega('transcricao') ? 'Transcrição: ' + pega('transcricao') : ''].filter(Boolean).join(' · ');
  const mAno = (pega('data', 'ano') + ' ').match(/\b(1[5-9]\d\d|20[0-2]\d)\b/);
  return montarRascunho({ titulo: limparTitulo(titulo), autor: pega('autor', 'autora', 'por'), ano: mAno ? mAno[1] : '', fonte: /^https?:\/\//i.test(fonteBruta) ? fonteBruta : '', credito, html, arquivo: nome });
}

function importarColado(htmlOuTexto, ehHtml, nomeSugerido) {
  if (ehHtml) {
    const doc = new DOMParser().parseFromString(htmlOuTexto, 'text/html');
    const meta = prepararDoc(doc, nomeSugerido || 'Texto colado');
    const ex = extrairCorpo(doc, '');
    return montarRascunho({ ...meta, html: ex.html, arquivo: 'colado', avisos: ex.avisos.concat(ex.indice ? [AVISO_INDICE] : []) });
  }
  return importarTexto(htmlOuTexto, nomeSugerido || 'Texto colado', { md: false, juntar: true });
}

async function decodificar(file) { return decodificarBytes(new Uint8Array(await file.arrayBuffer())); }

async function lerArquivo(file, opc = {}) {
  const ext = ((file.name.match(/\.([a-z0-9]+)$/i) || [])[1] || '').toLowerCase();
  if (['pdf', 'doc', 'docx', 'epub', 'odt', 'rtf'].includes(ext)) throw new Error(`Arquivos .${ext} ainda não são lidos. Converta para .txt, .md ou .html antes de enviar.`);
  if (file.size > 12 * 1048576) throw new Error('Arquivo grande demais (limite de 12 MB).');
  const { texto, cod } = await decodificar(file);
  let r;
  if (['html', 'htm', 'xhtml'].includes(ext) || /^\s*(<!doctype html|<html|<head|<body)/i.test(texto.slice(0, 600))) r = importarHtml(texto, file.name);
  else if (['md', 'markdown'].includes(ext)) r = importarTexto(texto, file.name, { md: true, juntar: opc.juntar !== false });
  else r = importarTexto(texto, file.name, { md: false, juntar: opc.juntar !== false });
  r.cod = cod;
  return r;
}

/* ---- páginas do marxists.org lidas ao vivo ---- */
const nomeDaUrl = url => { try { const u = new URL(url); const seg = u.pathname.split('/').filter(Boolean).pop() || u.hostname; return seg.replace(/\.[a-z0-9]+$/i, ''); } catch (e) { return 'página'; } };

/* links da página que apontam para outras páginas da mesma pasta: candidatos a capítulos da obra */
function capitulosDe(doc, url) {
  let base; try { base = new URL(url); } catch (e) { return []; }
  const dir = base.pathname.replace(/[^/]*$/, '');
  const vistos = new Set([semFragmento(base.href)]); const out = [];
  for (const a of doc.body.querySelectorAll('a[href]')) {
    const h = (a.getAttribute('href') || '').trim();
    if (!h || h.startsWith('#') || /^(mailto|javascript|tel):/i.test(h)) continue;
    let u; try { u = new URL(h, base); } catch (e) { continue; }
    if (!MIA_RE.test(u.hostname)) continue;
    u.hash = ''; u.protocol = 'https:';
    if (!u.pathname.startsWith(dir) || u.pathname === dir) continue;
    if (u.pathname === dir + 'index.htm' || u.pathname === dir + 'index.html') continue;
    if (!/\.(html?|xhtml)$/i.test(u.pathname)) continue;
    if (vistos.has(u.href)) continue;
    const t = (a.textContent || '').replace(/\s+/g, ' ').trim();
    if (t.length < 2 || LIXO_LINK.test(fold(t))) continue;
    vistos.add(u.href); out.push({ t: t.slice(0, 200), u: u.href });
    if (out.length >= 300) break;
  }
  return out;
}

function importarPagina(raw, url, ehTxt) {
  if (ehTxt) { const r = importarTexto(raw, nomeDaUrl(url), { md: false, juntar: true }); return { ...r, fonte: url, candidatos: [], indice: false }; }
  const doc = new DOMParser().parseFromString(raw, 'text/html');
  const meta = prepararDoc(doc, nomeDaUrl(url));
  const candidatos = capitulosDe(doc, url);
  const ex = extrairCorpo(doc, url);
  return { ...meta, fonte: url, html: ex.html, avisos: ex.avisos, indice: ex.indice && candidatos.length >= 2, candidatos, bruto: ex.bruto };
}
