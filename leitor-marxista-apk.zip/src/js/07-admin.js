/* ============ área do editor: rascunhos, publicados, adicionar ============ */
function erroAmigavel(e) { return (e && e.message) || 'Algo deu errado.'; }

const TABS_ADMIN = [['rascunhos', 'Rascunhos'], ['publicados', 'Publicados'], ['adicionar', 'Adicionar']];

function telaAdmin(tab) {
  if (!TABS_ADMIN.some(t => t[0] === tab)) tab = 'rascunhos';
  $('#app').innerHTML = `<div class="pagina">
    <div><h1 class="titulo-pag">Admin</h1><p class="sub">Área do editor. Nada vai para a biblioteca sem passar pelo rascunho, e só quem tem o token do dono consegue publicar: o GitHub recusa qualquer outra pessoa. Os rascunhos ficam só neste aparelho.</p></div>
    ${!configOk() ? '<p class="nota-topo">O app não está ligado a um repositório (config.js). Veja o README.</p>' : ''}
    <nav class="abas" id="adm-abas" aria-label="Seções do admin"></nav>
    <div id="adm-corpo"></div></div>`;
  const pintarAbas = () => {
    const r = $('#adm-abas'); if (!r) return;
    const cont = { rascunhos: Lib.rasc.size, publicados: Lib.textos.size };
    r.innerHTML = TABS_ADMIN.map(([k, n]) => `<a href="#admin-${k}" ${k === tab ? 'aria-current="page"' : ''}>${n}${cont[k] != null ? ` (${cont[k]})` : ''}</a>`).join('');
  };
  pintarAbas();
  const corpo = $('#adm-corpo');
  if (tab === 'rascunhos') { E.refresh = () => { pintarAbas(); pintarRascunhos(corpo); }; E.refresh(); }
  else if (tab === 'publicados') { E.refresh = () => { pintarAbas(); pintarPublicados(corpo); }; E.refresh(); }
  else { E.refresh = pintarAbas; montarAdicionar(corpo); }
}

/* ---- rascunhos ---- */
function pintarRascunhos(el) {
  const l = [...Lib.rasc.values()].sort((a, b) => (b.atualizadoEm || 0) - (a.atualizadoEm || 0));
  if (!l.length) { el.innerHTML = `<div class="estado"><b>Nenhum rascunho</b>Endereços e arquivos que você adicionar aparecem aqui para conferência antes de entrar na biblioteca.<br><a class="btn" href="#admin-adicionar">Adicionar texto</a></div>`; return; }
  el.innerHTML = l.map(d => {
    const c = d.conferido || {}; const pronto = c.a && c.b && c.c; const vivo = d.tipo === 'ao-vivo';
    return `<div class="item-adm"><div><div class="t">${esc(d.titulo || '(sem título)')}</div><div class="m">${esc(d.autor || 'Sem autor')}${d.ano ? ' · ' + esc(d.ano) : ''} · ${kb(d.chars || 0)} · ${vivo ? 'ao vivo do marxists.org' : (d.arquivo ? 'de ' + esc(d.arquivo) : 'criado ' + fmtData(d.criadoEm))}</div></div>
      <div class="selos">${(d.chars || 0) < TEXTO_MINIMO ? '<span class="selo-e novo">Texto vazio</span>' : ''}${vivo ? '<span class="selo-e">Ao vivo</span>' : ''}<span class="selo-e ${pronto ? 'pronto' : 'novo'}">${pronto ? 'Conferido' : 'Falta conferir'}</span>${(d.avisos || []).length ? `<span class="selo-e novo">${d.avisos.length} aviso${d.avisos.length > 1 ? 's' : ''}</span>` : ''}${d.publicadoEm ? '<span class="selo-e">Já foi publicado</span>' : ''}</div>
      <div class="acoes"><a class="btn peq" href="#rascunho-${esc(d.id)}">Revisar e publicar</a><button class="btn perigo peq" type="button" data-descartar="${esc(d.id)}">Descartar</button></div></div>`;
  }).join('');
  $$('[data-descartar]', el).forEach(b => b.onclick = () => doisToques(b, 'Toque de novo para descartar', async () => {
    try { await apagarRascunho(b.dataset.descartar); aviso('Rascunho descartado'); } catch (e) { aviso(erroAmigavel(e)); }
  }));
}

/* ---- publicados ---- */
function pintarPublicados(el) {
  const l = [...Lib.textos.values()].sort((a, b) => (b.publicadoEm || 0) - (a.publicadoEm || 0));
  if (!l.length) { el.innerHTML = `<div class="estado"><b>Nada publicado</b>Quando você publicar um rascunho, ele aparece aqui.</div>`; return; }
  el.innerHTML = l.map(t => `<div class="item-adm"><div><div class="t">${esc(t.titulo)}</div><div class="m">${esc(t.autor || 'Sem autor')}${t.ano ? ' · ' + esc(t.ano) : ''} · ${t.tipo === 'ao-vivo' ? (t.capitulos && t.capitulos.length ? t.capitulos.length + ' capítulos, ao vivo' : 'ao vivo') : kb(t.chars || 0)} · publicado em ${fmtData(t.publicadoEm)}</div></div>
    <div class="acoes"><a class="btn sec peq" href="${rotaDeItem(t)}">Abrir</a><button class="btn sec peq" type="button" data-ed="${esc(t.id)}">Editar dados</button><button class="btn sec peq" type="button" data-rasc="${esc(t.id)}">Voltar para rascunho</button><button class="btn perigo peq" type="button" data-exc="${esc(t.id)}">Excluir</button></div></div>`).join('');
  $$('[data-ed]', el).forEach(b => b.onclick = () => editarDadosPublicado(Lib.textos.get(b.dataset.ed)));
  $$('[data-rasc]', el).forEach(b => b.onclick = () => doisToques(b, 'Toque de novo: sai da biblioteca', async () => {
    try { await despublicar(Lib.textos.get(b.dataset.rasc)); aviso('O texto voltou para os rascunhos'); } catch (e) { aviso(erroAmigavel(e), 5000); }
  }));
  $$('[data-exc]', el).forEach(b => b.onclick = () => doisToques(b, 'Toque de novo para excluir', async () => {
    try { await excluirPublicado(Lib.textos.get(b.dataset.exc)); aviso('Texto excluído'); } catch (e) { aviso(erroAmigavel(e), 5000); }
  }));
}

function camposMeta(d, prefixo) {
  const usados = [...new Set([...Lib.textos.values(), ...Lib.rasc.values()].flatMap(t => t.temas || []))].sort((a, b) => fold(a).localeCompare(fold(b), 'pt-BR'));
  return `<div class="grade2">
      <div class="campo"><label for="${prefixo}titulo">Título</label><input id="${prefixo}titulo" value="${esc(d.titulo)}" maxlength="300" autocomplete="off"></div>
      <div class="campo"><label for="${prefixo}autor">Autor</label><input id="${prefixo}autor" value="${esc(d.autor)}" maxlength="200" autocomplete="off"></div>
      <div class="campo"><label for="${prefixo}ano">Ano</label><input id="${prefixo}ano" value="${esc(d.ano)}" maxlength="20" inputmode="numeric" autocomplete="off"></div>
      <div class="campo"><label for="${prefixo}temas">Temas (separados por vírgula)</label><input id="${prefixo}temas" value="${esc((d.temas || []).join(', '))}" autocomplete="off"></div>
    </div>
    ${usados.length ? `<div class="chips" id="${prefixo}usados" aria-label="Temas já usados">${usados.slice(0, 14).map(u => `<button class="chip" type="button" data-tema="${esc(u)}" aria-pressed="false">+ ${esc(u)}</button>`).join('')}</div>` : ''}
    <div class="campo"><label for="${prefixo}fonte">Endereço de origem (URL)</label><input id="${prefixo}fonte" type="url" value="${esc(d.fonte)}" placeholder="https://www.marxists.org/portugues/…" autocomplete="off"><span class="dica">Aparece no cabeçalho do texto, com link para o original.</span></div>
    <div class="campo"><label for="${prefixo}credito">Crédito (tradução, transcrição, edição)</label><input id="${prefixo}credito" value="${esc(d.credito)}" autocomplete="off"></div>`;
}
function lerMeta(el, prefixo, d) {
  const v = k => ($('#' + prefixo + k, el).value || '').trim();
  d.titulo = v('titulo'); d.autor = v('autor'); d.ano = v('ano'); d.fonte = v('fonte'); d.credito = v('credito');
  d.temas = v('temas').split(',').map(s => s.trim()).filter(Boolean).filter((x, i, a) => a.indexOf(x) === i).slice(0, 12);
}
function ligarTemasUsados(el, prefixo) {
  const c = $('#' + prefixo + 'usados', el); if (!c) return;
  c.addEventListener('click', e => {
    const b = e.target.closest('[data-tema]'); if (!b) return;
    const inp = $('#' + prefixo + 'temas', el); const atual = inp.value.split(',').map(s => s.trim()).filter(Boolean);
    if (!atual.includes(b.dataset.tema)) atual.push(b.dataset.tema); inp.value = atual.join(', '); inp.dispatchEvent(new Event('input', { bubbles: true }));
  });
}

function editarDadosPublicado(t) {
  if (!t) return;
  Folha.abrir({
    titulo: 'Editar dados',
    html: camposMeta(t, 'pe-') + `<div class="acoes"><button class="btn" id="pe-ok" type="button">Salvar</button></div><p class="rodape-leve">Para mudar o texto em si, use “Voltar para rascunho”, edite e publique de novo.</p>`,
    montar: el => {
      ligarTemasUsados(el, 'pe-');
      $('#pe-ok', el).onclick = async () => {
        const d = { ...t }; lerMeta(el, 'pe-', d);
        if (!d.titulo) { aviso('O título não pode ficar vazio'); return; }
        try { await salvarMetaPublicado(t, d); Folha.fechar(); aviso('Dados atualizados'); } catch (e) { aviso(erroAmigavel(e)); }
      };
    },
  });
}

/* ---- adicionar ---- */
/* busca a página no marxists.org e cria um rascunho "ao vivo" (o texto continua vindo do site) */
async function criarRascunhoDeUrl(url, aoEstado = () => { }) {
  const u = normalizarUrlMia(url); if (!u) throw new Error('Esse endereço não é do marxists.org.');
  aoEstado('Buscando a página no marxists.org…');
  const pg = await lerPagina(u, { forcar: true });
  const m = pg.meta || {}; const cand = pg.candidatos || [];
  const d = montarRascunho({
    titulo: m.titulo || nomeDaUrl(u), autor: m.autor || '', ano: m.ano || '', credito: m.credito || '', fonte: u, html: pg.html, arquivo: u, cod: pg.cod,
    avisos: pg.avisos || [], tipo: 'ao-vivo', url: u, candidatos: cand, temCapitulos: !!pg.indice, capitulos: pg.indice ? cand : [],
  });
  await gravarRascunho(d);
  return d.id;
}

function montarAdicionar(el) {
  el.innerHTML = `<div class="espaco-v">
    <section class="zona">
      <h2 class="secao">Do marxists.org (ao vivo)</h2>
      <p class="sub" style="margin:0 0 12px">Cole o endereço da página. O texto continua vindo do site na hora em que o leitor abrir, e o app guarda uma cópia para ler sem internet. Se a página for o índice de uma obra, o app detecta os capítulos.</p>
      <form id="url-form" autocomplete="off" novalidate><div class="campo"><label for="url-novo">Endereço da página</label><input id="url-novo" type="text" inputmode="url" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="https://www.marxists.org/portugues/…"></div>
      <div class="acoes" style="margin-top:12px"><button class="btn" id="url-ok" type="submit">Buscar e criar rascunho</button><a class="btn sec" href="#ler-${chaveDeUrl(URL_MIA_PT)}">Navegar no marxists.org</a></div></form>
      <p class="rodape-leve" id="url-estado" style="margin-top:10px">Dica: navegue pelo site dentro do app; ao achar o texto, abra o painel ≡ › Sobre e toque em “Criar rascunho desta página”.</p>
    </section>
    <section class="zona" id="zona">
      <h2 class="secao">Enviar arquivos</h2>
      <p class="sub" style="margin:0 0 12px">Para textos que não estão no marxists.org. Aceita <b>.html</b>, <b>.txt</b> e <b>.md</b>. O conteúdo fica guardado no seu repositório.</p>
      <div class="campo"><label for="arq">Escolher arquivos</label><input id="arq" type="file" multiple accept=".txt,.md,.markdown,.html,.htm,.xhtml,text/plain,text/html,text/markdown"></div>
      <label style="display:flex;gap:8px;align-items:flex-start;margin-top:12px;font-size:.88rem"><input type="checkbox" id="manter" style="margin-top:3px;accent-color:var(--acento)"> Manter as quebras de linha dos .txt (use para poemas e versos)</label>
      <ul class="lista-env" id="env-lista" style="margin-top:12px"></ul>
    </section>
    <section class="zona">
      <h2 class="secao">Colar texto</h2>
      <p class="sub" style="margin:0 0 12px">Copie o texto de qualquer lugar e cole aqui. Títulos e parágrafos são preservados quando vierem de uma página da web.</p>
      <div class="colar" id="colar" contenteditable="true" role="textbox" aria-multiline="true" aria-label="Área para colar o texto" data-ph="Cole o texto aqui"></div>
      <div class="campo" style="margin-top:12px"><label for="colar-url">Endereço de origem (opcional)</label><input id="colar-url" type="url" placeholder="https://…" autocomplete="off"></div>
      <div class="acoes" style="margin-top:12px"><button class="btn" id="colar-ok" type="button">Criar rascunho</button></div>
    </section></div>`;
  const lista = $('#env-lista', el);
  let colado = { html: '', texto: '' };
  const linha = (cls, html) => { const li = document.createElement('li'); li.innerHTML = `<span class="${cls}">${cls === 'ok' ? '✓' : cls === 'er' ? '✕' : '…'}</span><span>${html}</span>`; lista.appendChild(li); return li; };

  $('#url-form', el).onsubmit = async e => {
    e.preventDefault();
    const st = $('#url-estado', el); const bt = $('#url-ok', el);
    bt.disabled = true;
    try { const id = await criarRascunhoDeUrl($('#url-novo', el).value, m => { st.textContent = m; }); irPara('rascunho-' + id); }
    catch (er) { st.textContent = erroAmigavel(er); bt.disabled = false; }
  };

  async function processar(arquivos) {
    let ultimo = null; let ok = 0;
    for (const f of arquivos) {
      const li = linha('', `Lendo ${esc(f.name)}…`);
      try {
        const d = await lerArquivo(f, { juntar: !$('#manter', el).checked });
        await gravarRascunho(d);
        li.innerHTML = `<span class="ok">✓</span><span><b>${esc(d.titulo)}</b> virou rascunho (${kb(d.chars)}). <a href="#rascunho-${esc(d.id)}">Revisar</a></span>`;
        ultimo = d; ok++;
      } catch (e) { li.innerHTML = `<span class="er">✕</span><span>${esc(f.name)}: ${esc(erroAmigavel(e))}</span>`; }
    }
    if (ok === 1 && arquivos.length === 1 && ultimo) irPara('rascunho-' + ultimo.id);
    else if (ok > 1) aviso(`${ok} rascunhos criados`);
  }
  $('#arq', el).addEventListener('change', e => { const fs = [...e.target.files]; e.target.value = ''; if (fs.length) processar(fs); });

  const colar = $('#colar', el);
  colar.addEventListener('paste', e => {
    const cd = e.clipboardData; if (!cd) return;
    e.preventDefault();
    const h = cd.getData('text/html'); const t = cd.getData('text/plain');
    colado = { html: h, texto: t };
    if (h) { const doc = new DOMParser().parseFromString(h, 'text/html'); colar.innerHTML = limparHtml(doc.body, ''); }
    else colar.textContent = t;
  });
  colar.addEventListener('input', () => { if (!colar.textContent.trim()) colado = { html: '', texto: '' }; });
  $('#colar-ok', el).onclick = async () => {
    if (!colar.textContent.trim()) { aviso('Cole um texto primeiro'); return; }
    try {
      let d;
      if (colado.html) d = importarColado(colado.html, true, 'Texto colado');
      else if (colar.querySelector('p,h1,h2,h3,li,br')) d = importarColado(colar.innerHTML, true, 'Texto colado');
      else d = importarColado(colar.textContent, false, 'Texto colado');
      const url = ($('#colar-url', el).value || '').trim(); if (/^https?:\/\//i.test(url)) d.fonte = url;
      await gravarRascunho(d);
      irPara('rascunho-' + d.id);
    } catch (e) { aviso(erroAmigavel(e)); }
  };
}

/* ---- editor de rascunho ---- */
async function telaRascunho(id) {
  const app = $('#app');
  app.innerHTML = '<p class="carregando">Abrindo rascunho…</p>';
  const mesma = () => E.rota.nome === 'rascunho' && E.rota.arg === id;
  let ed;
  try { ed = await carregarRascunho(id); } catch (e) { if (mesma()) app.innerHTML = `<div class="pagina"><div class="estado"><b>Não consegui abrir o rascunho</b>${esc(e.message || '')}<br><a class="btn" href="#admin-rascunhos">Voltar</a></div></div>`; return; }
  if (!mesma()) return;
  if (!ed) { app.innerHTML = `<div class="pagina"><div class="estado"><b>Rascunho não encontrado</b>Ele pode ter sido publicado ou descartado.<br><a class="btn" href="#admin-rascunhos">Voltar aos rascunhos</a></div></div>`; return; }
  ed.conferido = { a: false, b: false, c: false, ...(ed.conferido || {}) };
  const vivo = ed.tipo === 'ao-vivo';
  if (vivo && !ed.html) { try { const pg = await lerPagina(ed.url); ed.html = pg.html; ed.chars = tamTexto(ed.html); ed.candidatos = pg.candidatos || ed.candidatos || []; } catch (e) { /* o aviso de texto vazio explica */ } if (!mesma()) return; }
  const nCand = (ed.candidatos || []).length;

  const duplicado = () => [...Lib.textos.values()].find(t => t.id !== ed.id && ((vivo && ed.url && t.url === ed.url) || (fold(t.titulo.trim()) === fold((ed.titulo || '').trim()) && fold((t.autor || '').trim()) === fold((ed.autor || '').trim()))));
  const secCaps = vivo && nCand ? `<section class="espaco-v"><h2 class="secao">2. Capítulos</h2>
      <div class="checks"><label><input type="checkbox" id="r-temcap"><span>Esta é uma obra com vários capítulos: o leitor vê a lista e navega de um para outro.</span></label></div>
      <div id="r-caps" hidden><p class="rodape-leve" style="margin:10px 0">O app achou ${nCand} páginas na mesma pasta do endereço. Desmarque as que não são capítulos (apêndices, notas soltas…).</p>
        <div class="checks" id="r-caps-lista">${ed.candidatos.map((c, i) => `<label><input type="checkbox" data-cap="${i}"><span>${esc(c.t)}</span></label>`).join('')}</div>
        <div class="acoes"><a class="btn sec peq" id="r-testar" href="#">Abrir o 1º capítulo marcado (teste)</a></div></div></section>` : '';
  const nPrev = secCaps ? 3 : 2;
  app.innerHTML = `<div class="pagina">
    <div><a href="#admin-rascunhos" style="font-size:.86rem;font-weight:600">← Rascunhos</a><h1 class="titulo-pag" style="margin-top:8px">Revisar rascunho</h1>
    <p class="sub">${vivo ? 'Ao vivo do marxists.org · ' : (ed.arquivo ? 'Origem: ' + esc(ed.arquivo) + ' · ' : '')}${kb(ed.chars || 0)}${ed.publicadoEm ? ' · este texto já esteve publicado' : ''}</p></div>
    <div class="avisos" id="r-avisos"></div>
    <section class="espaco-v"><h2 class="secao">1. Dados do texto</h2>${camposMeta(ed, 'r-')}</section>
    ${secCaps}
    <section><h2 class="secao">${nPrev}. Pré-visualização <small>como o leitor verá</small></h2>
      ${vivo ? '<div class="acoes" style="margin-bottom:10px"><button class="btn sec peq" id="r-reler" type="button">Buscar de novo no site</button></div>' : ''}
      <div class="previa"><div class="texto" id="r-previa"></div></div></section>
    ${vivo ? '' : '<details class="fonte-html" id="r-det"><summary>Corrigir o texto (avançado)</summary><div class="dentro"><p class="rodape-leve" style="margin:0">Edite o HTML do texto, ou apague tudo e cole texto simples (parágrafos separados por linha em branco). Ao aplicar, a conferência abaixo volta a zero.</p><textarea id="r-src" spellcheck="false" aria-label="HTML do texto"></textarea><div class="acoes"><button class="btn sec peq" id="r-aplicar" type="button">Aplicar alterações</button></div></div></details>'}
    <section class="espaco-v"><h2 class="secao">${nPrev + (vivo ? 1 : 1)}. Conferência</h2>
      <div class="checks">
        <label><input type="checkbox" data-ck="a"><span>Título e autor estão certos.</span></label>
        <label><input type="checkbox" data-ck="b"><span>Rolei a pré-visualização${secCaps ? ' e abri um capítulo' : ''}: o texto está completo e sem lixo de página.</span></label>
        <label><input type="checkbox" data-ck="c"><span>Endereço de origem e crédito estão preenchidos (ou não existem).</span></label>
      </div>
      <div class="acoes"><button class="btn" id="r-publicar" type="button">Publicar na biblioteca</button><button class="btn perigo" id="r-descartar" type="button">Descartar rascunho</button></div>
      <p class="rodape-leve" id="r-estado"></p>
    </section></div>`;
  const raiz = $('.pagina', app);
  $('#r-previa', raiz).innerHTML = ed.html || '<p class="rodape-leve">O texto está vazio.</p>';

  const pintarAvisos = () => {
    const av = [...(ed.avisos || [])];
    const bl = bloqueioDeTexto(ed.html); if (bl && !av.includes(bl)) av.unshift(bl);
    if (vivo && ed.temCapitulos && !(ed.capitulos || []).length) av.push('Nenhum capítulo marcado.');
    if (!(ed.titulo || '').trim()) av.push('Falta o título.'); if (!(ed.autor || '').trim()) av.push('Falta o autor.');
    const dup = duplicado(); if (dup) av.push(`Já existe na biblioteca um texto parecido (“${dup.titulo}”). Publicar este vai criar uma segunda cópia.`);
    $('#r-avisos', raiz).innerHTML = av.map(a => `<div class="aviso-l">${esc(a)}</div>`).join('');
  };
  const pintarBotao = () => {
    const c = ed.conferido; const vazio = bloqueioDeTexto(ed.html);
    const semCaps = vivo && ed.temCapitulos && !(ed.capitulos || []).length;
    const ok = !vazio && !semCaps && c.a && c.b && c.c && (ed.titulo || '').trim() && (ed.autor || '').trim();
    $('#r-publicar', raiz).disabled = !ok;
    $('#r-estado', raiz).textContent = vazio ? 'Publicação bloqueada: o texto está vazio ou curto demais.' : ok ? 'Tudo conferido. Pode publicar.' : 'Preencha título e autor e marque as três conferências para liberar a publicação.';
  };
  let encerrado = false; /* depois de publicar ou descartar, nada pode recriar o rascunho */
  const salvarMeta = debounce(async () => { if (encerrado) return; try { await gravarRascunho(ed, { corpo: false }); } catch (e) { aviso(erroAmigavel(e)); } }, 700);
  E.aoSair = () => { if (!encerrado) salvarMeta.agora(); };
  window.addEventListener('pagehide', () => { if (!encerrado && mesma()) salvarMeta.agora(); }, { once: true });
  $$('[data-ck]', raiz).forEach(cb => { cb.checked = !!ed.conferido[cb.dataset.ck]; cb.onchange = () => { ed.conferido[cb.dataset.ck] = cb.checked; pintarBotao(); salvarMeta(); }; });
  ['titulo', 'autor', 'ano', 'temas', 'fonte', 'credito'].forEach(k => $('#r-' + k, raiz).addEventListener('input', () => { lerMeta(raiz, 'r-', ed); pintarAvisos(); pintarBotao(); salvarMeta(); }));
  ligarTemasUsados(raiz, 'r-');

  /* capítulos (só para páginas ao vivo que listam outras páginas da mesma pasta) */
  if (secCaps) {
    const marcados = () => new Set((ed.capitulos || []).map(c => c.u));
    const pintarCaps = () => {
      const sel = marcados();
      $('#r-temcap', raiz).checked = !!ed.temCapitulos; $('#r-caps', raiz).hidden = !ed.temCapitulos;
      $$('[data-cap]', raiz).forEach(cb => { cb.checked = sel.has(ed.candidatos[+cb.dataset.cap].u); });
      const prim = ed.candidatos.find(c => sel.has(c.u)); const a = $('#r-testar', raiz);
      a.setAttribute('href', prim ? '#ler-' + chaveDeUrl(prim.u) : '#'); a.hidden = !prim;
    };
    $('#r-temcap', raiz).onchange = e => { ed.temCapitulos = e.target.checked; if (ed.temCapitulos && !(ed.capitulos || []).length) ed.capitulos = [...ed.candidatos]; pintarCaps(); pintarAvisos(); pintarBotao(); salvarMeta(); };
    $('#r-caps-lista', raiz).onchange = () => { ed.capitulos = ed.candidatos.filter((c, i) => $(`[data-cap="${i}"]`, raiz).checked); pintarCaps(); pintarAvisos(); pintarBotao(); salvarMeta(); };
    pintarCaps();
  }
  pintarAvisos(); pintarBotao();

  if (vivo) {
    $('#r-reler', raiz).onclick = async e => {
      const b = e.currentTarget; b.disabled = true; b.textContent = 'Buscando…';
      try {
        const pg = await lerPagina(ed.url, { forcar: true });
        const sel = new Set((ed.capitulos || []).map(c => c.u));
        ed.html = pg.html; ed.chars = tamTexto(ed.html); ed.candidatos = pg.candidatos || [];
        ed.capitulos = ed.temCapitulos ? ed.candidatos.filter(c => sel.has(c.u)) : [];
        ed.avisos = (pg.avisos || []).concat(avisosDe(ed.html, ed.chars, ed));
        ed.conferido = { a: false, b: false, c: false };
        await gravarRascunho(ed, { corpo: true }); aviso('Texto atualizado. Confira de novo.'); telaRascunho(id);
      } catch (er) { aviso(erroAmigavel(er), 5000); b.disabled = false; b.textContent = 'Buscar de novo no site'; }
    };
  } else {
    $('#r-det', raiz).addEventListener('toggle', e => { const t = $('#r-src', raiz); if (e.target.open && !t.value) t.value = ed.html; });
    $('#r-aplicar', raiz).onclick = async () => {
      const bruto = $('#r-src', raiz).value;
      if (/<\/?[a-z][a-z0-9]*[\s>\/]/i.test(bruto)) { const doc = new DOMParser().parseFromString(bruto, 'text/html'); ed.html = extrairCorpo(doc, ed.fonte).html; }
      else ed.html = textoParaHtml(bruto); /* sem tags: é texto puro, parágrafos separados por linha em branco */
      ed.chars = tamTexto(ed.html); ed.avisos = avisosDe(ed.html, ed.chars);
      ed.conferido = { a: false, b: false, c: false };
      $$('[data-ck]', raiz).forEach(cb => { cb.checked = false; });
      $('#r-previa', raiz).innerHTML = ed.html || '<p class="rodape-leve">O texto está vazio.</p>'; pintarAvisos(); pintarBotao();
      try { await gravarRascunho(ed, { corpo: true }); aviso('Texto atualizado. Confira de novo.'); } catch (e) { aviso(erroAmigavel(e)); }
    };
  }
  $('#r-descartar', raiz).onclick = e => doisToques(e.currentTarget, 'Toque de novo para descartar', async () => {
    encerrado = true; E.aoSair = null;
    try { await apagarRascunho(id); aviso('Rascunho descartado'); irPara('admin-rascunhos'); } catch (er) { encerrado = false; aviso(erroAmigavel(er)); }
  });
  $('#r-publicar', raiz).onclick = async e => {
    const b = e.currentTarget; lerMeta(raiz, 'r-', ed);
    b.disabled = true; const txt = b.textContent; b.textContent = 'Publicando…';
    try {
      await salvarMeta.agora();
      await publicarRascunho(ed, (i, n) => { b.textContent = `Publicando… ${i}/${n}`; });
      encerrado = true; E.aoSair = null;
      aviso('Publicado na biblioteca'); irPara('admin-publicados');
    } catch (er) { aviso(erroAmigavel(er), 6000); b.disabled = false; b.textContent = txt; }
  };
}

Object.assign(ROTAS, { admin: telaAdmin, rascunho: telaRascunho });
