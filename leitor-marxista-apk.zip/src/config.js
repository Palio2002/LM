/* Ligação do app ao seu repositório do GitHub. O fluxo de build (GitHub Actions) preenche isto sozinho.
   Se você compilar à mão, troque os valores abaixo. O repositório precisa ser PÚBLICO. */
window.LM_CONFIG = { repo: "__REPO__", branch: "__BRANCH__", pasta: "catalogo", versao: "__VERSAO__" };
