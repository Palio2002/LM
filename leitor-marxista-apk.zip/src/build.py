"""Junta style.css + body.html + js/*.js em www/index.html (um arquivo só, sem dependências)."""
import pathlib
base = pathlib.Path(__file__).parent
css = (base/'style.css').read_text(encoding='utf-8')
body = (base/'body.html').read_text(encoding='utf-8')
js = '\n'.join((base/'js'/f).read_text(encoding='utf-8') for f in sorted(p.name for p in (base/'js').glob('*.js')))
assert '</script' not in js.lower()
pagina = ('<!doctype html>\n<html lang="pt-BR"><head><meta charset="utf-8">\n'
          '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'
          '<meta name="color-scheme" content="light dark">\n<meta name="theme-color" content="#8f0b16">\n'
          '<title>Leitor Marxista</title>\n'
          '<style>:root{color-scheme:light dark}[hidden]{display:none!important}body{margin:0}</style>\n'
          f'<style>\n{css}\n</style>\n<script src="config.js"></script>\n</head><body>\n{body}\n'
          f'<script>\n(() => {{\n\'use strict\';\n{js}\n}})();\n</script>\n</body></html>\n')
out = base.parent/'www'/'index.html'
out.write_text(pagina, encoding='utf-8')
(base.parent/'www'/'config.js').write_text((base/'config.js').read_text(encoding='utf-8'), encoding='utf-8')
print('www/index.html', len(pagina)//1024, 'KB')
