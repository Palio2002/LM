# Leitor Marxista (app Android)

Um leitor para celular que **lê o Arquivo Marxista na Internet (marxists.org) ao vivo**, com marcações coloridas, notas, busca, obras em capítulos e leitura sem internet. Só o dono da biblioteca consegue adicionar textos.

## Como funciona (em 5 linhas)

- O texto é buscado no marxists.org na hora em que a pessoa abre; o app guarda uma cópia no celular para ler offline.
- Os links do marxists.org dentro dos textos (próximo capítulo, notas, outras obras) abrem dentro do app.
- A **biblioteca** (lista de obras escolhidas por você) fica no arquivo `catalogo/catalogo.json` deste repositório do GitHub. Todo mundo lê; **só quem tem o seu token escreve**. O GitHub é quem garante isso, não o app.
- Os **rascunhos** (a área de conferência antes de publicar) ficam só no seu celular.
- As **marcações, notas e favoritos** de cada pessoa ficam só no celular dela.

---

## Passo a passo para ter o APK (sem instalar nada no computador)

Você vai usar o GitHub só para "compilar" o app. Leva uns 20 minutos na primeira vez.

### 1. Conta e repositório

1. Crie uma conta grátis em **github.com** (se ainda não tiver).
2. Clique em **+ › New repository**. Nome sugerido: `leitor-marxista`. Marque **Public** (precisa ser público para os leitores conseguirem ver a biblioteca) e marque também **Add a README file**. Clique em **Create repository**.

### 2. Enviar o projeto (um único arquivo)

Não precisa descompactar nada. Dá para fazer tudo pelo celular.

1. Na página do repositório, toque em **Add file › Upload files**.
2. Escolha o arquivo **`leitor-marxista-apk.zip`** (o próprio `.zip`, fechado) e toque em **Commit changes**.

### 3. Criar o "compilador" (colar um texto)

1. Ainda na página do repositório: **Add file › Create new file**.
2. No campo do nome, digite exatamente `.github/workflows/apk.yml` (as barras criam as pastas sozinhas).
3. Cole dentro do editor **todo** o texto do arquivo `workflow-apk.yml.txt` (ele vem dentro do `.zip`; se você recebeu o texto na conversa, use esse).
4. Toque em **Commit changes**.

### 4. Gerar o APK

1. Abra a aba **Actions**. Se pedir, toque em **I understand my workflows, go ahead and enable them**.
2. Toque em **Gerar APK** (lista à esquerda ou em "All workflows") e depois em **Run workflow › Run workflow**.
3. Espere de 8 a 15 minutos até aparecer o **✓ verde**.
   - Se aparecer **✗ vermelho**, abra a execução, copie as últimas linhas do erro e me mande: eu corrijo.

### 5. Instalar no celular

1. No celular, abra a página do repositório e toque em **Releases** (lado direito, ou aba "Releases").
2. Baixe **`leitor-marxista.apk`** da versão mais recente.
3. Abra o arquivo baixado. O Android vai pedir permissão para **instalar apps desta fonte**: permita só para o navegador que você usou. Depois toque em **Instalar**.
4. Para os seus leitores: mande o link da página **Releases** do repositório. Eles instalam do mesmo jeito.

### 6. Primeiro teste

Abra o app e vá em **Ajustes › Testar conexão**. Deve aparecer algo como:

```
Aparelho: app Android · HTTP nativo: sim
Repositório do catálogo: seu-usuario/leitor-marxista (main)
marxists.org: resposta 200, … KB, … · acentos ok
Catálogo no GitHub: resposta 200, 0 texto(s)
```

Se algo disso disser **FALHOU**, **NÃO** ou **ATENÇÃO**, me mande o texto inteiro.

### 7. Ligar o seu modo editor (só você)

O modo editor precisa de um **token**: uma senha que dá ao app permissão de escrever **só neste repositório**.

1. No GitHub (pelo navegador): foto do perfil › **Settings** › (no fim do menu) **Developer settings** › **Personal access tokens** › **Fine-grained tokens** › **Generate new token**.
2. **Token name:** `leitor-marxista`. **Expiration:** o prazo que preferir (o máximo costuma ser 1 ano; anote para renovar).
3. **Repository access › Only select repositories** › escolha `leitor-marxista`.
4. **Permissions › Repository permissions › Contents › Read and write**. Deixe o resto como está.
5. **Generate token**. Copie o texto que começa com `github_pat_…` (ele só aparece uma vez).
6. No app: **Ajustes › Modo editor**, cole o token e toque em **Entrar no modo editor**. A aba **Admin** aparece.

**Guarde o token como uma senha.** Quem tiver o token consegue alterar a biblioteca. Se perder ou vazar, apague-o em Settings › Developer settings e crie outro.

---

## Como adicionar textos (aba Admin)

**Do marxists.org (ao vivo):** Admin › Adicionar › cole o endereço da página › *Buscar e criar rascunho*.
- Se a página for o **índice de uma obra** (lista de capítulos), o app detecta os capítulos: confira a lista, desmarque o que não for capítulo.
- Dica: use **Navegar no marxists.org** (ou o botão na tela Início); ao achar o texto, abra o painel ≡ › **Sobre** › *Criar rascunho desta página*.

**Arquivo ou texto colado:** para textos que não estão no marxists.org. O conteúdo é gravado no seu repositório (`catalogo/textos/`).

Em todos os casos o texto vira **rascunho**. Você confere título, autor, pré-visualização e crédito, marca as três confirmações e só então toca em **Publicar na biblioteca**. Um texto vazio nunca pode ser publicado.

Depois de publicar, os leitores veem a novidade em **1 a 2 minutos** (o GitHub guarda a lista em cache por pouco tempo).

---

## Atualizar o app

Recebeu uma versão nova do app (um `.zip` novo)? Em **Add file › Upload files**, envie o novo `.zip` **com o mesmo nome** (ele substitui o antigo; deixe só um `.zip` na raiz do repositório). O APK é gerado sozinho; se não começar, use **Actions › Gerar APK › Run workflow**. Instale o novo APK por cima do antigo: marcações e favoritos são mantidos. Publicar textos **não** exige gerar APK novo.

## Limites honestos

- O app só abre páginas de **marxists.org** (por segurança). Links para outros sites abrem no navegador.
- O marxists.org é mantido por voluntários e tem condições de uso próprias: confira-as no site. O app sempre mostra o link e o crédito de origem de cada texto.
- Se o marxists.org mudar o desenho das páginas, a limpeza automática pode deixar sobras (menus, rodapés) em alguns textos: por isso existe o rascunho de conferência.
- O backup das marcações é por **copiar e colar** (Ajustes), porque o Android não deixa apps gravarem arquivos soltos.
- Este projeto foi preparado sem acesso a um celular Android real: a camada do app foi testada em um navegador com o marxists.org e o GitHub simulados. Por isso existe o **Testar conexão** nos Ajustes.

## Avançado: sua própria chave de assinatura

Por padrão o APK é assinado com uma chave que está em `signing/` (conveniente, mas pública). Para um app só seu isso é aceitável; se quiser a sua, crie uma chave e, em **Settings › Secrets and variables › Actions**, cadastre `KEYSTORE_BASE64` (o arquivo `.keystore` em base64), `KEYSTORE_SENHA` e `KEYSTORE_ALIAS`. O fluxo passa a usá-la sozinho. Atenção: trocar de chave exige **desinstalar** o app antigo (as marcações guardadas no celular se perdem; faça o backup em Ajustes antes).

## Pastas

- `www/`: o app (um `index.html` + `config.js`). É isso que vai para dentro do APK.
- `src/`: o código-fonte organizado do app (`python3 src/build.py` gera o `www/index.html`).
- `catalogo/`: a biblioteca (o app edita `catalogo.json` sozinho quando você publica).
- `assets/`: ícone e tela de abertura.
- `signing/`: chave padrão de assinatura.
- `.github/workflows/apk.yml`: o "compilador" na nuvem (no repositório, ele fica ao lado do `.zip`; o texto está em `workflow-apk.yml.txt`).

Também funciona o jeito antigo: se você enviar as pastas soltas (em vez do `.zip`), o compilador usa os arquivos como estão.
